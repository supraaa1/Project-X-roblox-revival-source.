<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'];
$error = "";
$cost = 100;

// Obtener datos actualizados del usuario
try {
    $stmt_user = $pdo->prepare("SELECT rank, is_verified, robux FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user_data = $stmt_user->fetch();
    $user_rank = $user_data['rank'] ?? 'User';
    $is_verified = $user_data['is_verified'] ?? 0;
    $current_robux = $user_data['robux'] ?? 0;
} catch (PDOException $e) {
    $user_rank = 'User';
    $is_verified = 0;
    $current_robux = 0;
}

// Lógica de procesamiento
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $group_name = $_POST['name'];
    $group_desc = $_POST['description'];
    
    if ($current_robux < $cost) {
        $error = "You do not have enough Robux to create a group.";
    } elseif (empty($group_name)) {
        $error = "Group name is required.";
    } else {
        // Ajustado a 'default_group.png' según tu predeterminado en la DB
        $logo_name = "default_group.png"; 
        
        if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
            $target_dir = "uploads/groups/";
            if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
            
            $extension = pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION);
            $logo_name = bin2hex(random_bytes(10)) . "." . $extension;
            move_uploaded_file($_FILES['thumbnail']['tmp_name'], $target_dir . $logo_name);
        }

        try {
            $pdo->beginTransaction();

            // 1. Restar Robux
            $update_stmt = $pdo->prepare("UPDATE users SET robux = robux - ? WHERE id = ?");
            $update_stmt->execute([$cost, $user_id]);

            // 2. Insertar Grupo (Usando 'logo' según tu imagen de phpMyAdmin)
            // Se omiten shout_text y shout_author_id ya que pueden ser NULL
            $insert_stmt = $pdo->prepare("INSERT INTO groups (name, description, owner_id, logo) VALUES (?, ?, ?, ?)");
            $insert_stmt->execute([$group_name, $group_desc, $user_id, $logo_name]);

            $pdo->commit();
            header("Location: groups.php?id=" . $pdo->lastInsertId());
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            // Esto te ayudará a ver el error real si vuelve a fallar
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

// Cargar renders para el sidebar
try {
    $stmt_renders = $pdo->query("SELECT item_id, render_url FROM fake_renders");
    $renders_map = $stmt_renders->fetchAll(PDO::FETCH_KEY_PAIR); 
} catch (PDOException $e) {
    $renders_map = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create A Group - Project X</title>
    <style>
        :root {
            --rbx-blue: #00A2FF;
            --rbx-bg: #E3E3E3;
            --text-main: #393B3D;
            --rbx-admin-red: #d9534f;
        }
        body { margin: 0; padding: 0; font-family: "Segoe UI", Arial, sans-serif; background-color: var(--rbx-bg); }
        .sidebar { width: 180px; background: white; height: calc(100vh - 40px); position: fixed; top: 40px; border-right: 1px solid #CCC; z-index: 1001; }
        .sidebar-user { padding: 10px 15px; display: flex; align-items: center; gap: 10px; border-bottom: 1px solid #E3E3E3; }
        .sidebar-user-img { width: 28px; height: 28px; background-color: #EEE; background-size: cover; border-radius: 50%; border: 1px solid #CCC; }
        .sidebar-user-name { font-size: 16px; font-weight: 500; color: var(--text-main); display: flex; align-items: center; gap: 4px; }
        .sidebar-item { padding: 8px 15px; display: flex; align-items: center; text-decoration: none; color: var(--text-main); font-size: 16px; }
        .sidebar-item:hover { background-color: #F2F2F2; }
        .sidebar-icon-container { width: 24px; margin-right: 12px; display: flex; align-items: center; }
        .sidebar-icon { width: 22px; height: 22px; fill: none; stroke: #232527; stroke-width: 2; }
        .main-container { margin-left: 180px; padding-top: 60px; display: flex; justify-content: center; }
        .content { width: 950px; background: white; border: 1px solid #CCC; padding: 30px; min-height: 600px; }
        h1 { font-size: 32px; font-weight: normal; margin-top: 0; }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-weight: bold; font-size: 13px; margin-bottom: 5px; }
        input[type="text"], textarea { width: 100%; border: 1px solid #A7A7A7; padding: 8px; box-sizing: border-box; }
        textarea { height: 250px; resize: none; }
        .cost-text { font-size: 13px; margin: 15px 0; color: #333; }
        .robux-icon { width: 14px; vertical-align: middle; }
        .purchase-btn { background: linear-gradient(to bottom, #02b102, #016b01); color: white; border: 1px solid #004d00; padding: 8px 30px; font-size: 18px; cursor: pointer; border-radius: 3px; font-weight: bold; }
        .error-msg { color: #d00; font-weight: bold; margin-bottom: 15px; }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="sidebar">
    <div class="sidebar-user">
        <div class="sidebar-user-img" id="sidebar-avatar"></div>
        <span class="sidebar-user-name">
            <?php echo htmlspecialchars($username); ?>
            <?php if ($is_verified == 1): ?>
                <img src="verified.png" style="width:16px;">
            <?php endif; ?>
        </span>
    </div>
    <a href="home.php" class="sidebar-item">Home</a>
    <a href="profile.php" class="sidebar-item">Profile</a>
    <a href="groups.php" class="sidebar-item" style="background: #F2F2F2;">Groups</a>
</div>

<div class="main-container">
    <div class="content">
        <h1>Create A Group</h1>

        <?php if ($error): ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Name:</label>
                <input type="text" name="name" maxlength="50" required>
            </div>

            <div class="form-group">
                <label>Description:</label>
                <textarea name="description"></textarea>
            </div>

            <div class="form-group">
                <label>Thumbnail:</label>
                <input type="file" name="thumbnail" accept="image/*">
            </div>

            <div class="cost-text">
                Creating a group costs <img src="robux.png" class="robux-icon" alt="R$"> <b>100</b>. 
                By clicking Purchase, your account will be charged <img src="robux.png" class="robux-icon" alt="R$"> <b>100</b>.
            </div>

            <button type="submit" class="purchase-btn">Purchase</button>
        </form>
    </div>
</div>

<script>
    const rendersMap = <?php echo json_encode($renders_map); ?>;
    window.onload = function() {
        const equippedId = localStorage.getItem('equipped_item_id');
        const sidebarAvatar = document.getElementById('sidebar-avatar');
        sidebarAvatar.style.backgroundImage = (equippedId && rendersMap[equippedId]) 
            ? `url('${rendersMap[equippedId]}')` 
            : `url('avatar.png')`;
    };
</script>

</body>
</html>