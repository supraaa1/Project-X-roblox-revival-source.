<?php
// 1. Iniciamos la sesión al principio de todo
session_start();

require_once 'db.php';

// Si el usuario ya está logueado, lo enviamos directamente a home.php
if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit();
}

$message = isset($_SESSION['register_success']) ? $_SESSION['register_success'] : "";
$error = "";

// 2. Lógica Unificada: Procesar Login (Header) y Registro (Cuerpo)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // --- LÓGICA DE LOGIN (HEADER) ---
    if (isset($_POST['login_submit'])) {
        $user = $_POST['username'];
        $pass = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$user]);
        $userData = $stmt->fetch();

        if ($userData && password_verify($pass, $userData['password'])) {
            // Verificar si la cuenta está aceptada (status != 'pending')
            if ($userData['status'] === 'pending') {
                $error = "Your account is still pending admin review.";
            } else {
                // Login exitoso: Guardamos datos en la sesión
                $_SESSION['user_id'] = $userData['id'];
                $_SESSION['username'] = $userData['username'];
                
                // Limpiar mensaje de registro si existía
                unset($_SESSION['register_success']);
                
                header("Location: home.php");
                exit();
            }
        } else {
            $error = "Invalid username or password.";
        }
    }

    // --- LÓGICA DE REGISTRO (FORMULARIO PRINCIPAL) ---
    if (isset($_POST['register_submit'])) {
        $user = $_POST['username'];
        $pass = $_POST['password'];
        $conf = $_POST['confirm_password'];
        $d_name = $_POST['discord_username'];
        $d_id = $_POST['discord_id'];

        if ($pass !== $conf) {
            $error = "Passwords do not match!";
        } else {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$user]);
            $stmtDiscord = $pdo->prepare("SELECT id FROM users WHERE discord_id = ?");
            $stmtDiscord->execute([$d_id]);

            if ($stmt->fetch()) {
                $error = "Username already taken!";
            } elseif ($stmtDiscord->fetch()) {
                $error = "This Discord ID is already linked to an account!";
            } else {
                $hashed_pass = password_hash($pass, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (username, password, discord_username, discord_id, status) VALUES (?, ?, ?, ?, 'pending')");
                if ($stmt->execute([$user, $hashed_pass, $d_name, $d_id])) {
                    $message = "Your application has been accepted! You can now log in using your username and password.";
                    $_SESSION['register_success'] = $message;
                    header("Location: " . $_SERVER['PHP_SELF']);
                    exit();
                } else {
                    $error = "Something went wrong. Try again.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Project X - Sign Up</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: url('backgroundregister.png') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Mini Header Styles */
        header {
            background: rgba(0, 0, 0, 0.4);
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(8px);
            z-index: 10;
        }

        .header-logo img {
            height: 35px;
            vertical-align: middle;
        }

        .header-login-form {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .header-input {
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            font-size: 13px;
            width: 130px;
        }

        .btn-login-header {
            background: #007bff;
            color: white;
            border: none;
            padding: 6px 15px;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            font-size: 13px;
        }

        .header-links {
            position: absolute;
            right: 20px;
            top: 50px;
            font-size: 11px;
            color: white;
        }

        .header-links a {
            color: white;
            text-decoration: none;
            margin-left: 10px;
        }

        /* Main Container Styles */
        .main-content {
            flex-grow: 1;
            display: flex;
            justify-content: flex-end; 
            align-items: center;
            padding-right: 10%; 
        }

        .register-container {
            background: rgba(255, 255, 255, 0.85); 
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            width: 300px; 
            text-align: center;
            backdrop-filter: blur(10px); 
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        h2 { 
            color: #333; 
            margin-bottom: 15px; 
            font-size: 1.4em;
            text-transform: uppercase; 
            font-weight: 900; 
        }

        .form-input {
            width: 100%;
            padding: 10px;
            margin: 6px 0;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 6px;
            box-sizing: border-box;
            background: rgba(244, 244, 244, 0.9);
            font-size: 13px;
        }

        .btn-signup {
            width: 100%;
            padding: 10px;
            background: #72a8e8; 
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: 0.2s;
        }

        .btn-signup:hover { background: #5a93d6; }
        
        .success { color: #27ae60; font-size: 13px; font-weight: bold; margin-bottom: 10px; }
        .error { color: #c0392b; font-size: 13px; font-weight: bold; margin-bottom: 10px; }
        .login-link { margin-top: 15px; display: block; color: #4a90e2; text-decoration: none; font-size: 12px; }
        
        hr { border: 0; border-top: 1px solid rgba(0, 0, 0, 0.05); margin: 12px 0; }
    </style>
</head>
<body>

<header>
    <div class="header-logo">
        <img src="projectx.png" alt="Project X">
    </div>
    <!-- Login Form in Header -->
    <form class="header-login-form" method="POST">
        <input type="text" class="header-input" placeholder="Username" name="username" required>
        <input type="password" class="header-input" placeholder="Password" name="password" required>
        <input type="text" class="header-input" placeholder="2FA Code" name="2fa"> <!-- Adorno -->
        <button type="submit" name="login_submit" class="btn-login-header">Log In</button>
    </form>
    <div class="header-links">
        <a href="#">Forgot Password?</a>
    </div>
</header>

<div class="main-content">
    <div class="register-container">
        <h2>SIGN UP NOW!</h2>
        
        <!-- Mostrar errores de Login o Registro -->
        <?php if($error) echo "<div class='error'>$error</div>"; ?>

        <?php if($message): ?>
            <div class="success"><?php echo $message; ?></div>
            <p style="font-size: 12px;">Welcome to Project X. Your account application has been accepted!</p>
            <a href="#" class="login-link" style="font-weight:bold; font-size:14px;">Now you can login in your Project X Account!</a>
            
            <form method="GET" style="margin-top:20px;">
                <button type="submit" name="new" class="login-link" style="background:none; border:none; cursor:pointer; font-size:11px; text-decoration:underline; width:100%;">Create another account</button>
            </form>
            <?php 
                if(isset($_GET['new'])) {
                    unset($_SESSION['register_success']);
                    header("Location: " . $_SERVER['PHP_SELF']);
                    exit();
                }
            ?>
        <?php else: ?>
            <form method="POST">
                <input type="text" name="username" class="form-input" placeholder="Username" required>
                <input type="password" name="password" class="form-input" placeholder="Password" required>
                <input type="password" name="confirm_password" class="form-input" placeholder="Confirm Password" required>
                <hr>
                <input type="text" name="discord_username" class="form-input" placeholder="Discord Name (User#0000)" required>
                <input type="text" name="discord_id" class="form-input" placeholder="Discord ID" required>
                
                <button type="submit" name="register_submit" class="btn-signup">Create Account</button>
            </form>
        <?php endif; ?>
        
        <a href="login.php" class="login-link">Already have an account? Log In</a>
    </div>
</div>

</body>
</html>