<?php
/**
 * Project X - Logout
 */

// 1. Inicializar la sesión.
// Aunque vamos a destruirla, PHP necesita acceder a la sesión actual para poder borrarla.
session_start();

// 2. Desactivar todas las variables de sesión.
// Esto limpia el array $_SESSION en memoria para la ejecución actual del script.
$_SESSION = array();

// 3. Si se desea destruir la sesión completamente, borre también la cookie de sesión.
// Nota: ¡Esto destruirá la sesión y no solo los datos de la sesión!
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 4. Finalmente, destruir la sesión en el servidor.
session_destroy();

// 5. Redirigir al usuario a la página de índice (login).
header("Location: index.php");
exit(); // Asegurar que no se ejecute más código después de la redirección.
?>