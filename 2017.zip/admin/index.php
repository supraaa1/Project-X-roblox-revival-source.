<?php
// 1. CONFIGURACIÓN DE ERRORES
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../db.php'; // Asegúrate de que db.php esté en la raíz

// 2. VERIFICACIÓN DE SEGURIDAD
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Consultamos el rango y verificación directamente de la DB por seguridad
$stmt_check = $pdo->prepare("SELECT rank, username, is_verified FROM users WHERE id = ?");
$stmt_check->execute([$_SESSION['user_id']]);
$user_db = $stmt_check->fetch();

if (!$user_db || $user_db['rank'] !== 'Admin') {
    header("Location: ../home.php");
    exit("No tienes permisos para acceder aquí.");
}

$username = $user_db['username'];
$is_verified = $user_db['is_verified'] ?? 0; // Guardamos el estado de verificado para el sidebar

try {
    // 3. OBTENER LISTA DE USUARIOS (Añadido is_verified para la tabla si lo necesitas luego)
    $stmt = $pdo->query("SELECT id, username, tix, robux, rank, is_verified FROM users ORDER BY id DESC");
    $all_users = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error en la consulta: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Project X</title>
    <style>
        :root {
            --rbx-blue: #00A2FF;
            --rbx-admin-red: #d9534f;
            --rbx-bg: #E3E3E3;
            --text-main: #393B3D;
            --border-light: #CCC;
        }

        body {
            margin: 0; padding: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            background-color: var(--rbx-bg);
        }

        /* --- SIDEBAR ESTILO HOME --- */
        .sidebar {
            width: 180px;
            background: white;
            height: calc(100vh - 40px);
            position: fixed;
            top: 40px;
            border-right: 1px solid var(--border-light);
            padding: 0;
            z-index: 1001;
        }

        .sidebar-user {
            padding: 10px 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid #E3E3E3;
            margin-bottom: 5px;
        }

        .sidebar-user-img {
            width: 28px; height: 28px;
            background-color: #EEE;
            background-image: url('../avatar.png');
            background-size: cover;
            border-radius: 50%;
            border: 1px solid #CCC;
        }

        .sidebar-user-name {
            font-size: 16px; font-weight: 500;
            color: var(--text-main);
            overflow: hidden; text-overflow: ellipsis;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        /* Estilo para la insignia de verificado */
        .verified-badge {
            width: 16px;
            height: 16px;
        }

        .sidebar-item {
            padding: 8px 15px;
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-main);
            font-size: 16px;
        }

        .sidebar-item:hover { background-color: #F2F2F2; }

        .sidebar-icon-container {
            width: 24px; height: 24px;
            margin-right: 12px;
            display: flex; align-items: center; justify-content: center;
        }

        .sidebar-icon {
            width: 20px; height: 20px;
            fill: none; stroke: #232527; stroke-width: 2;
        }

        /* --- CONTENEDOR PRINCIPAL --- */
        .main-content {
            margin-left: 180px;
            padding: 60px 20px 20px 20px;
        }

        .admin-container {
            max-width: 1100px;
            margin: 0 auto;
            background: white;
            border: 1px solid var(--border-light);
            padding: 20px;
        }

        .admin-header {
            border-bottom: 2px solid var(--rbx-admin-red);
            margin-bottom: 20px;
            padding-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        h1 { color: #333; margin: 0; font-size: 22px; }
        
        .user-table {
            width: 100%;
            border-collapse: collapse;
        }

        .user-table th {
            background: #f8f8f8;
            text-align: left;
            padding: 12px;
            border: 1px solid var(--border-light);
            font-size: 13px;
            color: #666;
        }

        .user-table td {
            padding: 12px;
            border: 1px solid var(--border-light);
            font-size: 14px;
        }

        .rank-badge {
            padding: 3px 8px;
            border-radius: 3px;
            font-weight: bold;
            font-size: 11px;
            display: inline-block;
        }

        .rank-Admin { background: #ffdede; color: #d9534f; border: 1px solid #d9534f; }
        .rank-User { background: #e3f2fd; color: #00A2FF; border: 1px solid #00A2FF; }

        .btn-action {
            padding: 5px 10px;
            text-decoration: none;
            color: white;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        .btn-edit { background: #00A2FF; }
        .btn-ban { background: #333; margin-left: 5px; }

        .back-link { color: #00A2FF; text-decoration: none; font-size: 14px; font-weight: bold; }
    </style>
</head>
<body>

<?php include '../header.php'; ?>

<div class="sidebar">
    <div class="sidebar-user">
        <div class="sidebar-user-img"></div>
        <span class="sidebar-user-name">
            <?php echo htmlspecialchars($username); ?>
            <?php if ($is_verified == 1): ?>
                <img src="../verified.png" class="verified-badge" title="Verified">
            <?php endif; ?>
        </span>
    </div>

    <a href="../home.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
        </div>
        Home
    </a>
    
    <a href="../profile.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
        </div>
        Profile
    </a>
    
    <a href="../inventory.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24" stroke="currentColor"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
        </div>
        Inventory
    </a>

    <a href="index.php" class="sidebar-item" style="background: #F2F2F2; font-weight: bold;">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24" stroke="currentColor" style="stroke: var(--rbx-admin-red);"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
        </div>
        Admin
    </a>
</div>

<div class="main-content">
    <div class="admin-container">
        <div class="admin-header">
            <h1>Admin Control Panel</h1>
            <a href="../home.php" class="back-link">← Volver al Sitio</a>
        </div>

        <table class="user-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Robux</th>
                    <th>Tix</th>
                    <th>Rango</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($all_users as $user): ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td>
                        <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                        <?php if (isset($user['is_verified']) && $user['is_verified'] == 1): ?>
                            <img src="../verified.png" style="width:14px; vertical-align:middle;" title="Verified">
                        <?php endif; ?>
                    </td>
                    <td>
                        <img src="../robux.png" style="width:14px; vertical-align:middle;"> 
                        <?php echo number_format($user['robux']); ?>
                    </td>
                    <td>
                        <img src="../tix.png" style="width:14px; vertical-align:middle;"> 
                        <?php echo number_format($user['tix']); ?>
                    </td>
                    <td>
                        <span class="rank-badge rank-<?php echo htmlspecialchars($user['rank']); ?>">
                            <?php echo htmlspecialchars($user['rank']); ?>
                        </span>
                    </td>
                    <td>
                        <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn-action btn-edit">Editar</a>
                        <a href="ban.php?id=<?php echo $user['id']; ?>" class="btn-action btn-ban">Ban</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>