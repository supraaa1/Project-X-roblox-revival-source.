<?php
// 1. CONFIGURACIÓN DE ERRORES
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// CORRECCIÓN: En InfinityFree usa la ruta absoluta para evitar problemas de open_basedir
require_once __DIR__ . '/db.php'; 

// 2. VERIFICACIÓN DE SEGURIDAD (Solo Admins)
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$stmt_check = $pdo->prepare("SELECT rank, username FROM users WHERE id = ?");
$stmt_check->execute([$_SESSION['user_id']]);
$user_db = $stmt_check->fetch();

if (!$user_db || $user_db['rank'] !== 'Admin') {
    header("Location: home.php");
    exit("No tienes permisos.");
}

$username = $user_db['username'];

// 3. PROCESAR ACCIONES (Aceptar o Rechazar)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $target_id = $_GET['id'];

    if ($action === 'accept') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'accepted' WHERE id = ?");
        $stmt->execute([$target_id]);
    } elseif ($action === 'reject') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'rejected' WHERE id = ?");
        $stmt->execute([$target_id]);
    }
    header("Location: pending.php");
    exit();
}

// 4. OBTENER USUARIOS PENDIENTES
try {
    $stmt = $pdo->query("SELECT id, username, discord_username, discord_id, join_date FROM users WHERE status = 'pending' ORDER BY join_date ASC");
    $pending_users = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pending Users - Admin</title>
    <style>
        :root {
            --rbx-blue: #00A2FF;
            --rbx-admin-red: #d9534f;
            --rbx-bg: #E3E3E3;
            --text-main: #393B3D;
            --border-light: #CCC;
        }

        body { margin: 0; padding: 0; font-family: "Segoe UI", Arial, sans-serif; background-color: var(--rbx-bg); }

        /* --- SIDEBAR --- */
        .sidebar { width: 180px; background: white; height: calc(100vh - 40px); position: fixed; top: 40px; border-right: 1px solid var(--border-light); z-index: 1001; }
        .sidebar-user { padding: 10px 15px; display: flex; align-items: center; gap: 10px; border-bottom: 1px solid #E3E3E3; }
        .sidebar-user-img { width: 28px; height: 28px; background-color: #EEE; background-image: url('avatar.png'); background-size: cover; border-radius: 50%; border: 1px solid #CCC; }
        .sidebar-user-name { font-size: 16px; font-weight: 500; color: var(--text-main); }
        .sidebar-item { padding: 8px 15px; display: flex; align-items: center; text-decoration: none; color: var(--text-main); font-size: 16px; }
        .sidebar-item:hover { background-color: #F2F2F2; }
        .sidebar-icon-container { width: 24px; margin-right: 12px; display: flex; justify-content: center; }
        .sidebar-icon { width: 20px; height: 20px; fill: none; stroke: #232527; stroke-width: 2; }

        /* --- CONTENIDO --- */
        .main-content { margin-left: 180px; padding: 60px 20px 20px 20px; }
        .admin-container { max-width: 1000px; margin: 0 auto; background: white; border: 1px solid var(--border-light); padding: 20px; }
        
        .admin-header { border-bottom: 2px solid var(--rbx-admin-red); margin-bottom: 20px; padding-bottom: 10px; }
        h1 { font-size: 22px; color: #333; margin: 0; }

        .pending-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .pending-table th { background: #F8F8F8; padding: 12px; border: 1px solid var(--border-light); text-align: left; font-size: 13px; color: #666; }
        .pending-table td { padding: 12px; border: 1px solid var(--border-light); font-size: 14px; }

        .discord-info { color: #5865F2; font-weight: bold; font-size: 12px; }

        .btn-action { padding: 6px 12px; text-decoration: none; border-radius: 3px; font-weight: bold; font-size: 12px; display: inline-block; }
        .btn-accept { background: #28a745; color: white; margin-right: 5px; }
        .btn-reject { background: #dc3545; color: white; }
        .btn-accept:hover { background: #218838; }
        .btn-reject:hover { background: #c82333; }
        
        .no-pending { text-align: center; padding: 40px; color: #999; font-style: italic; }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="sidebar">
    <div class="sidebar-user">
        <div class="sidebar-user-img"></div>
        <span class="sidebar-user-name"><?php echo htmlspecialchars($username); ?></span>
    </div>

    <a href="home.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
        </div>
        Home
    </a>

    <a href="pending.php" class="sidebar-item" style="background: #F2F2F2; font-weight: bold;">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24" stroke="var(--rbx-admin-red)"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><line x1="19" y1="8" x2="19" y2="14"></line><line x1="22" y1="11" x2="16" y2="11"></line></svg>
        </div>
        Pending App.
    </a>
</div>

<div class="main-content">
    <div class="admin-container">
        <div class="admin-header">
            <h1>Pending Applications</h1>
        </div>

        <?php if (count($pending_users) > 0): ?>
            <table class="pending-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Discord</th>
                        <th>Join Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pending_users as $user): ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                        <td>
                            <div class="discord-info"><?php echo htmlspecialchars($user['discord_username']); ?></div>
                            <small style="color:#888;"><?php echo htmlspecialchars($user['discord_id']); ?></small>
                        </td>
                        <td><?php echo $user['join_date']; ?></td>
                        <td>
                            <a href="pending.php?action=accept&id=<?php echo $user['id']; ?>" class="btn-action btn-accept">Accept</a>
                            <a href="pending.php?action=reject&id=<?php echo $user['id']; ?>" class="btn-action btn-reject" onclick="return confirm('¿Seguro que quieres rechazar a este usuario?')">Reject</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-pending">
                <p>Nothing rn</p>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>