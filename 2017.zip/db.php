<?php
/**
 * Project X - Roblox 2017 Revival
 * Configuración de Base de Datos para InfinityFree
 */

// Datos extraídos de tu panel de control
$host    = 'sql305.infinityfree.com';
$db_name = 'if0_41873492_tuffadminpanel';
$user    = 'if0_41873492';
$pass    = 'jZClTz72fDXrlUb';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Conexión principal para Project X
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Si hay un error, lo mostramos para saber qué falló
    die("Error in Project X: " . $e->getMessage());
}
?>