<?php
// 1. Obtenemos los datos del usuario actual (Robux, Tix y el último cobro)
if (isset($_SESSION['user_id'])) {
    // IMPORTANTE: Asegúrate de añadir la columna 'last_reward' (DATETIME) a tu tabla 'users'
    $stmt_user = $pdo->prepare("SELECT robux, tix, last_reward FROM users WHERE id = ? LIMIT 1");
    $stmt_user->execute([$_SESSION['user_id']]);
    $user_data = $stmt_user->fetch();
    
    $user_robux = $user_data['robux'] ?? 0;
    $user_tix = $user_data['tix'] ?? 0;
    $last_reward = $user_data['last_reward'];

    // --- LÓGICA DE RECOMPENSA CADA 1 HORA ---
    $now = new DateTime();
    
    if (!$last_reward) {
        // Si es la primera vez, marcamos "ahora" como su último cobro para que empiece a contar
        $stmt_init = $pdo->prepare("UPDATE users SET last_reward = NOW() WHERE id = ?");
        $stmt_init->execute([$_SESSION['user_id']]);
    } else {
        $last_time = new DateTime($last_reward);
        $diff = $now->diff($last_time);
        
        // Calculamos cuántas horas totales han pasado
        $hours_passed = ($diff->days * 24) + $diff->h;

        if ($hours_passed >= 1) {
            $reward_amount = $hours_passed * 5; // 50 Robux por cada hora
            
            // Actualizamos los Robux y reseteamos el contador de tiempo basándonos en las horas pagadas
            // Usamos una suma en SQL para evitar errores de duplicación
            $stmt_pay = $pdo->prepare("UPDATE users SET robux = robux + ?, last_reward = DATE_ADD(last_reward, INTERVAL ? HOUR) WHERE id = ?");
            $stmt_pay->execute([$reward_amount, $hours_passed, $_SESSION['user_id']]);
            
            // Actualizamos la variable local para que se vea el cambio de inmediato en el header
            $user_robux += $reward_amount;
        }
    }
    // ----------------------------------------

} else {
    $user_robux = 0;
    $user_tix = 0;
}

// 2. Obtenemos el alert desde la base de datos
$stmt_alert = $pdo->query("SELECT alert_text, alert_enabled FROM site_settings LIMIT 1");
$site_alert = $stmt_alert->fetch();
?>
<style>
    nav {
        background-color: #0074BD;
        height: 40px;
        display: flex;
        align-items: center;
        padding: 0 10px;
        color: white;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        position: fixed;
        width: 100%;
        top: 0;
        left: 0;
        z-index: 1000;
        box-sizing: border-box;
        border-bottom: 1px solid #005a91;
    }

    .nav-left { display: flex; gap: 18px; align-items: center; }
    
    .nav-logo-img { 
        height: 32px; 
        cursor: pointer; 
        margin-right: 5px;
    }

    .nav-link { 
        color: white; 
        text-decoration: none; 
        font-weight: 600; 
        font-size: 15px; 
    }
    
    .search-container {
        position: relative;
        margin-left: 10px;
    }

    .nav-search {
        background: white;
        border: none;
        padding: 5px 30px 5px 10px;
        border-radius: 2px;
        width: 280px;
        font-size: 14px;
        outline: none;
    }

    .search-icon {
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
        color: #333;
        font-size: 16px;
        pointer-events: none;
    }

    .nav-right {
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 15px;
        padding-right: 10px;
    }

    .nav-stats {
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 13px;
        font-weight: 600;
    }

    .stat-item { display: flex; align-items: center; gap: 5px; }

    .nav-icon {
        width: 20px;
        height: 20px;
        object-fit: contain;
    }

    .settings-icon {
        width: 18px;
        height: 18px;
        fill: white;
        cursor: pointer;
        transition: transform 0.2s ease;
    }
    
    .settings-icon:hover {
        transform: rotate(45deg);
    }

    .orange-banner-container {
        position: fixed;
        top: 40px; 
        left: 180px; 
        width: calc(100% - 180px); 
        z-index: 999;
    }

    .orange-banner {
        background: #FFA500;
        color: white;
        text-align: center;
        padding: 6px 10px;
        font-weight: bold;
        font-size: 13px;
        border-bottom: 1px solid rgba(0,0,0,0.1);
    }
</style>

<nav>
    <div class="nav-left">
        <img src="projectx.png" class="nav-logo-img" alt="Project X" onclick="window.location.href='home.php'">
        <a href="games.php" class="nav-link">Games</a>
        <a href="catalog.php" class="nav-link">Catalog</a>
        <a href="create.php" class="nav-link">Create</a>
        
        <div class="search-container">
            <input type="text" class="nav-search" placeholder="Search">
            <span class="search-icon"></span>
        </div>
    </div>

    <div class="nav-right">
        <div class="nav-stats">
            <span><?php echo htmlspecialchars($username); ?>: 13+</span>
            <div class="stat-item">
                <img src="robux.png" class="nav-icon" alt="R$"> 
                <?php echo number_format($user_robux); ?>
            </div>
            <div class="stat-item">
                <img src="tix.png" class="nav-icon" alt="T$"> 
                <?php echo number_format($user_tix); ?>
            </div>
            
            <div class="stat-item">
                <svg class="settings-icon" viewBox="0 0 24 24">
                    <path d="M19.14,12.94c0.04-0.3,0.06-0.61,0.06-0.94c0-0.32-0.02-0.64-0.07-0.94l2.03-1.58c0.18-0.14,0.23-0.41,0.12-0.61 l-1.92-3.32c-0.12-0.22-0.37-0.29-0.59-0.22l-2.39,0.96c-0.5-0.38-1.03-0.7-1.62-0.94L14.4,2.81c-0.04-0.24-0.24-0.41-0.48-0.41 h-3.84c-0.24,0-0.43,0.17-0.47,0.41L9.25,5.35C8.66,5.59,8.12,5.92,7.63,6.29L5.24,5.33c-0.22-0.08-0.47,0-0.59,0.22L2.74,8.87 C2.62,9.08,2.66,9.34,2.86,9.48l2.03,1.58C4.84,11.36,4.81,11.69,4.81,12c0,0.31,0.02,0.64,0.07,0.94l-2.03,1.58 c-0.18,0.14-0.23,0.41-0.12,0.61l1.92,3.32c0.12,0.22,0.37,0.29,0.59,0.22l2.39-0.96c0.5,0.38,1.03,0.7,1.62,0.94l0.36,2.54 c0.05,0.24,0.24,0.41,0.48,0.41h3.84c0.24,0,0.44-0.17,0.47-0.41l0.36-2.54c0.59-0.24,1.13-0.56,1.62-0.94l2.39,0.96 c0.22,0.08,0.47,0,0.59-0.22l1.92-3.32c0.12-0.22,0.07-0.47-0.12-0.61L19.14,12.94z M12,15.6c-1.98,0-3.6-1.62-3.6-3.6 s1.62-3.6,3.6-3.6s3.6,1.62,3.6,3.6S13.98,15.6,12,15.6z"/>
                </svg>
            </div>
        </div>
        <a href="logout.php" style="color:white; font-size:11px; text-decoration: none;">Logout</a>
    </div>
</nav>

<?php if ($site_alert && $site_alert['alert_enabled']): ?>
    <div class="orange-banner-container">
        <div class="orange-banner">
            <?php echo htmlspecialchars($site_alert['alert_text']); ?>
        </div>
    </div>
<?php endif; ?>