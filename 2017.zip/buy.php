<?php
// 1. Configuración de errores y cabeceras
ini_set('display_errors', 0); // Desactivar en producción para no romper el JSON
header('Content-Type: application/json');

session_start();
require_once 'db.php';

$response = ['success' => false, 'message' => 'Unknown error'];

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Session expired.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$item_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

try {
    // INICIAMOS TRANSACCIÓN INMEDIATAMENTE para bloquear las filas
    $pdo->beginTransaction();

    // 2. Obtener datos del item con FOR UPDATE para evitar que otros procesos lo modifiquen a la vez
    $stmt = $pdo->prepare("SELECT price, is_limited, stock, afterstock_price FROM catalog_items WHERE id = ? FOR UPDATE");
    $stmt->execute([$item_id]);
    $item = $stmt->fetch();

    if (!$item) {
        throw new Exception("Item not found.");
    }

    $is_limited = (isset($item['is_limited']) && $item['is_limited'] == 1);
    $current_stock = (int)$item['stock'];
    
    // LÓGICA DE PRECIO: 
    // Si es limitado y no hay stock, usamos el precio de "agotado" (si existe), si no, el normal.
    if ($is_limited && $current_stock <= 0) {
        $price = $item['afterstock_price'] ?? $item['price'];
        // Si quieres que NO se pueda comprar si no hay stock aunque cambie el precio, descomenta la siguiente línea:
        // throw new Exception("This limited item is sold out!");
    } else {
        $price = $item['price'];
    }

    // 3. Verificar saldo del usuario (también bloqueamos la fila del usuario)
    $stmt_u = $pdo->prepare("SELECT robux FROM users WHERE id = ? FOR UPDATE");
    $stmt_u->execute([$user_id]);
    $user = $stmt_u->fetch();

    if ($user['robux'] < $price) {
        throw new Exception("You don't have enough Robux.");
    }

    // 4. EJECUTAR OPERACIONES

    // A. Restar saldo al usuario
    $update_balance = $pdo->prepare("UPDATE users SET robux = robux - ? WHERE id = ?");
    $update_balance->execute([$price, $user_id]);

    // B. Actualizar stock (SOLO si es limitado y TODAVÍA tiene stock)
    if ($is_limited && $current_stock > 0) {
        // IMPORTANTE: Solo restamos 1 y verificamos que sea > 0 en la misma query
        $update_stock = $pdo->prepare("UPDATE catalog_items SET stock = stock - 1 WHERE id = ? AND stock > 0");
        $update_stock->execute([$item_id]);
        
        if ($update_stock->rowCount() === 0) {
            throw new Exception("Item sold out at the last millisecond.");
        }
    }

    // C. Registrar en inventario
    // Verificamos si ya lo tiene para evitar duplicados si tu lógica lo requiere
    $check_inv = $pdo->prepare("SELECT id FROM inventory WHERE user_id = ? AND item_id = ?");
    $check_inv->execute([$user_id, $item_id]);
    if ($check_inv->fetch()) {
        // Opcional: throw new Exception("You already own this item.");
    }

    $add_inv = $pdo->prepare("INSERT INTO inventory (user_id, item_id) VALUES (?, ?)");
    $add_inv->execute([$user_id, $item_id]);

    // 5. Confirmar todo
    $pdo->commit();
    
    $response['success'] = true;
    $response['message'] = 'Purchase successful!';
    $response['new_balance'] = $user['robux'] - $price;

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response);