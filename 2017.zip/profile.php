<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// 1. OBTENER DATOS EXTENDIDOS DEL USUARIO
try {
    $stmt_user = $pdo->prepare("SELECT rank, is_verified, join_date FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user_data = $stmt_user->fetch();
    $user_rank = $user_data['rank'] ?? 'User';
    $is_verified = $user_data['is_verified'] ?? 0;
    $join_date = $user_data['join_date'] ?? date("Y-m-d");
} catch (PDOException $e) {
    $user_rank = 'User';
    $is_verified = 0;
    $join_date = date("Y-m-d");
}

$default_avatar = "avatar.png";

try {
    // 2. CONSULTAR QUÉ TIENE EQUIPADO ACTUALMENTE
    $stmt_eq = $pdo->prepare("SELECT item_id FROM equipped_items WHERE user_id = ?");
    $stmt_eq->execute([$user_id]);
    $currently_equipped = $stmt_eq->fetchAll(PDO::FETCH_COLUMN, 0); 

    // 3. MAPA DE RENDERS (Para el Sidebar y el Perfil)
    $stmt_renders = $pdo->query("SELECT item_id, render_url FROM fake_renders");
    $renders_map = $stmt_renders->fetchAll(PDO::FETCH_KEY_PAIR); 

    // 4. DETERMINAR EL RENDER ACTUAL PARA EL PERFIL (Fallback de PHP)
    $current_render = $default_avatar;
    if (!empty($currently_equipped)) {
        $last_item_id = end($currently_equipped); 
        if (isset($renders_map[$last_item_id])) {
            $current_render = $renders_map[$last_item_id];
        }
    }

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($username); ?> - Profile</title>
    <style>
        :root {
            --rbx-blue: #00A2FF;
            --rbx-bg: #E3E3E3;
            --text-main: #393B3D;
            --rbx-admin-red: #d9534f;
        }

        body {
            margin: 0; padding: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            background-color: var(--rbx-bg);
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: 180px;
            background: white;
            height: calc(100vh - 40px);
            position: fixed;
            top: 40px;
            border-right: 1px solid #CCC;
            padding: 0;
            z-index: 1001;
        }

        .sidebar-user {
            padding: 10px 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid #E3E3E3;
            margin-bottom: 5px;
        }

        .sidebar-user-img {
            width: 28px;
            height: 28px;
            background-color: #EEE;
            background-size: cover;
            background-position: center;
            border-radius: 50%;
            border: 1px solid #CCC;
        }

        .sidebar-user-name {
            font-size: 16px;
            font-weight: 500;
            color: var(--text-main);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .verified-badge {
            width: 16px;
            height: 16px;
        }

        .sidebar-item {
            padding: 8px 15px;
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-main);
            font-size: 16px;
            transition: background 0.1s;
        }

        .sidebar-item:hover { background-color: #F2F2F2; }

        .sidebar-icon-container {
            width: 24px; height: 24px;
            margin-right: 12px;
            display: flex; align-items: center; justify-content: center;
        }

        .sidebar-icon {
            width: 22px; height: 22px;
            fill: none; stroke: #232527;
            stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
        }

        .nav-badge {
            margin-left: auto;
            background-color: var(--rbx-blue);
            color: white;
            font-size: 11px;
            font-weight: bold;
            padding: 2px 6px;
            border-radius: 10px;
        }

        .btn-upgrade-container { padding: 10px; margin-top: 5px; }
        .btn-upgrade {
            background-color: var(--rbx-blue);
            color: white; border: none; padding: 10px;
            width: 100%; border-radius: 4px; font-weight: bold;
            font-size: 15px; cursor: pointer; text-align: center;
        }

        /* --- CONTENEDOR PRINCIPAL PERFIL --- */
        .main-container {
            margin-left: 180px;
            padding-top: 60px;
            display: flex;
            justify-content: center;
        }

        .content-profile {
            width: 950px;
            padding: 20px;
        }

        .profile-header {
            background: white;
            border: 1px solid #CCC;
            padding: 25px;
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .avatar-main-circle {
            width: 130px;
            height: 130px;
            background-color: #F0F0F0;
            background-size: cover;
            background-position: center;
            border-radius: 50%;
            border: 1px solid #BBB;
            flex-shrink: 0;
        }

        .section-box {
            background: white;
            border: 1px solid #CCC;
            margin-top: 20px;
            padding: 20px;
        }

        .wearing-container { 
            display: flex; 
            justify-content: center; /* Centramos el render ya que quitamos la lista */
            padding: 10px 0;
        }
        
        .render-display {
            width: 320px; height: 320px;
            background: #F9F9F9; border: 1px solid #DDD;
            display: flex; align-items: center; justify-content: center;
        }
        .render-display img { max-width: 100%; max-height: 100%; }

    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="sidebar">
    <div class="sidebar-user">
        <div class="sidebar-user-img" id="sidebar-avatar"></div>
        <span class="sidebar-user-name">
            <?php echo htmlspecialchars($username); ?>
            <?php if ($is_verified == 1): ?>
                <img src="verified.png" class="verified-badge" title="Verified">
            <?php endif; ?>
        </span>
    </div>

    <a href="home.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
        </div>
        Home
    </a>
    
    <a href="profile.php" class="sidebar-item" style="background: #F2F2F2;">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24" style="stroke: var(--rbx-blue);"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
        </div>
        <span style="color: var(--rbx-blue); font-weight: bold;">Profile</span>
    </a>
    
    <a href="messages.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        </div>
        Messages
    </a>
    
    <a href="friends.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        </div>
        Friends <span class="nav-badge">0</span>
    </a>
    
    <a href="avatar.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M12 2a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zM9 22V12h6v10M4 7h16M4 7l2 5h12l2-5"></path></svg>
        </div>
        Avatar
    </a>
    
    <a href="inventory.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
        </div>
        Inventory
    </a>

    <?php if ($user_rank === 'Admin'): ?>
    <a href="admin/index.php" class="sidebar-item" style="color: var(--rbx-admin-red); font-weight: bold;">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" style="stroke: var(--rbx-admin-red);" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
        </div>
        Admin
    </a>
    <?php endif; ?>

    <div class="btn-upgrade-container">
        <button class="btn-upgrade">Upgrade Now</button>
    </div>
</div>

<div class="main-container">
    <div class="content-profile">
        <div class="profile-header">
            <div class="avatar-main-circle" id="profile-circle-avatar"></div>
            <div class="user-details">
                <h1 style="margin:0; font-size:30px;">
                    <?php echo htmlspecialchars($username); ?>
                    <?php if ($is_verified == 1): ?>
                        <img src="verified.png" class="verified-badge">
                    <?php endif; ?>
                </h1>
                <p style="color: #777; margin: 5px 0;">Rank: <b><?php echo htmlspecialchars($user_rank); ?></b></p>
            </div>
        </div>

        <div class="section-box">
            <h2>About</h2>
            <p>Player since: <?php echo date("d/m/Y", strtotime($join_date)); ?></p>
        </div>

        <div class="section-box">
            <h2>Currently Wearing</h2>
            <div class="wearing-container">
                <div class="render-display">
                    <img src="<?php echo $current_render; ?>" id="profile-main-render">
                </div>
                </div>
        </div>
    </div>
</div>

<script>
    const rendersMap = <?php echo json_encode($renders_map); ?>;
    const defaultImg = 'avatar.png';

    window.onload = function() {
        const equippedId = localStorage.getItem('equipped_item_id');
        
        const sidebarAvatar = document.getElementById('sidebar-avatar');
        const profileCircle = document.getElementById('profile-circle-avatar');
        const profileMain = document.getElementById('profile-main-render');

        if (equippedId && rendersMap[equippedId]) {
            const renderUrl = rendersMap[equippedId];
            
            sidebarAvatar.style.backgroundImage = `url('${renderUrl}')`;
            if(profileCircle) profileCircle.style.backgroundImage = `url('${renderUrl}')`;
            if(profileMain) profileMain.src = renderUrl;
            
        } else {
            sidebarAvatar.style.backgroundImage = `url('${defaultImg}')`;
            if(profileCircle) profileCircle.style.backgroundImage = `url('${defaultImg}')`;
            if(profileMain) profileMain.src = defaultImg;
        }
    };
</script>

</body>
</html>