<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'];

// MODIFICADO: Obtener el rango y el estado de verificación
try {
    $stmt_user = $pdo->prepare("SELECT rank, is_verified FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user_data = $stmt_user->fetch();
    $user_rank = $user_data['rank'] ?? 'User';
    $is_verified = $user_data['is_verified'] ?? 0; // 1 si está verificado, 0 si no
} catch (PDOException $e) {
    $user_rank = 'User';
    $is_verified = 0;
}

// Cargamos los renders para que JS pueda consultarlos
try {
    $stmt_renders = $pdo->query("SELECT item_id, render_url FROM fake_renders");
    $renders_map = $stmt_renders->fetchAll(PDO::FETCH_KEY_PAIR); 
} catch (PDOException $e) {
    $renders_map = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home - Project X</title>
    <style>
        :root {
            --rbx-blue: #00A2FF;
            --rbx-bg: #E3E3E3;
            --text-main: #393B3D;
            --rbx-admin-red: #d9534f;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            background-color: var(--rbx-bg);
        }

        /* Sidebar Estilo Imagen */
        .sidebar {
            width: 180px;
            background: white;
            height: calc(100vh - 40px);
            position: fixed;
            top: 40px;
            border-right: 1px solid #CCC;
            padding: 0;
            z-index: 1001;
        }

        /* Sección de Usuario Superior */
        .sidebar-user {
            padding: 10px 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid #E3E3E3;
            margin-bottom: 5px;
        }

        .sidebar-user-img {
            width: 28px;
            height: 28px;
            background-color: #EEE;
            background-size: cover;
            background-position: center;
            border-radius: 50%;
            border: 1px solid #CCC;
        }

        .sidebar-user-name {
            font-size: 16px;
            font-weight: 500;
            color: var(--text-main);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        /* Estilo para la insignia de verificado */
        .verified-badge {
            width: 16px;
            height: 16px;
            vertical-align: middle;
        }

        .sidebar-item {
            padding: 8px 15px;
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-main);
            font-size: 16px;
            transition: background 0.1s;
        }

        .sidebar-item:hover {
            background-color: #F2F2F2;
        }

        .sidebar-icon-container {
            width: 24px;
            height: 24px;
            margin-right: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sidebar-icon {
            width: 22px;
            height: 22px;
            fill: none;
            stroke: #232527;
            stroke-width: 2;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .nav-badge {
            margin-left: auto;
            background-color: var(--rbx-blue);
            color: white;
            font-size: 11px;
            font-weight: bold;
            padding: 2px 6px;
            border-radius: 10px;
        }

        .btn-upgrade-container {
            padding: 10px;
            margin-top: 5px;
        }

        .btn-upgrade {
            background-color: var(--rbx-blue);
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 4px;
            font-weight: bold;
            font-size: 15px;
            cursor: pointer;
            text-align: center;
        }

        /* Contenedor Principal */
        .main-container {
            margin-left: 180px;
            padding-top: 60px;
            display: flex;
            justify-content: center;
        }

        .content {
            width: 950px;
            display: flex;
            gap: 20px;
            padding: 20px;
        }

        .user-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .avatar-main {
            width: 120px;
            height: 120px;
            background-color: white;
            border: 1px solid #CCC;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .avatar-main img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .widget {
            background: white;
            border: 1px solid #CCC;
            padding: 15px;
            margin-bottom: 20px;
        }

        .welcome-text {
            display: flex;
            align-items: center;
            gap: 8px;
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="sidebar">
    <div class="sidebar-user">
        <div class="sidebar-user-img" id="sidebar-avatar"></div>
        <span class="sidebar-user-name">
            <?php echo htmlspecialchars($username); ?>
            <?php if ($is_verified == 1): ?>
                <img src="verified.png" class="verified-badge" title="Verified">
            <?php endif; ?>
        </span>
    </div>

    <a href="home.php" class="sidebar-item" style="background: #F2F2F2;">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
        </div>
        Home
    </a>
    
    <a href="profile.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
        </div>
        Profile
    </a>
    
    <a href="messages.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        </div>
        Messages
    </a>
    
    <a href="friends.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        </div>
        Friends
        <span class="nav-badge">0</span>
    </a>
    
    <a href="avatar.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M12 2a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zM9 22V12h6v10M4 7h16M4 7l2 5h12l2-5"></path></svg>
        </div>
        Avatar
    </a>
    
    <a href="inventory.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
        </div>
        Inventory
    </a>

    <a href="trade.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><polyline points="16 3 21 3 21 8"></polyline><line x1="4" y1="20" x2="21" y2="3"></line><polyline points="21 16 21 21 16 21"></polyline><line x1="15" y1="15" x2="21" y2="21"></line><line x1="4" y1="4" x2="9" y2="9"></line></svg>
        </div>
        Trade
    </a>

    <a href="groups.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path><path d="M2 12h20"></path></svg>
        </div>
        Groups
    </a>

    <a href="forums.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 1 1-7.6-10.6 8.5 8.5 0 0 1 3.4 1.2L21 4z"></path></svg>
        </div>
        Forums
    </a>

    <a href="download.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
        </div>
        Download
    </a>

    <?php if ($user_rank === 'Admin'): ?>
    <a href="admin/index.php" class="sidebar-item" style="color: var(--rbx-admin-red); font-weight: bold;">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" style="stroke: var(--rbx-admin-red);" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
        </div>
        Admin
    </a>

    <a href="pending.php" class="sidebar-item" style="color: var(--rbx-admin-red); font-weight: bold;">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" style="stroke: var(--rbx-admin-red);" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><line x1="19" y1="8" x2="19" y2="14"></line><line x1="22" y1="11" x2="16" y2="11"></line></svg>
        </div>
        Pending App.
    </a>
    <?php endif; ?>

    <div class="btn-upgrade-container">
        <button class="btn-upgrade">Upgrade Now</button>
    </div>
</div>

<div class="main-container">
    <div class="content">
        <div style="flex: 1;">
            <div class="user-header">
                <div class="avatar-main">
                    <img id="home-avatar" src="avatar.png">
                </div>
                <h1 class="welcome-text">
                    Hello, <?php echo htmlspecialchars($username); ?>!
                    <?php if ($is_verified == 1): ?>
                        <img src="verified.png" style="width: 24px; height: 24px;" title="Verified">
                    <?php endif; ?>
                </h1>
            </div>
            
            <div class="widget">
                <div class="widget-title">
                    <span>Friends (0)</span>
                </div>
                <div style="display:flex; gap:10px;">
                    <div style="width:80px; text-align:center;">
                        </div>
                </div>
            </div>
        </div>
        
        <div style="width: 160px; background: #DDD; height: 600px; text-align: center; line-height: 600px; color: #999;">
            AD
        </div>
    </div>
</div>

<script>
    const rendersMap = <?php echo json_encode($renders_map); ?>;
    const defaultImg = 'avatar.png';

    window.onload = function() {
        const equippedId = localStorage.getItem('equipped_item_id');
        const sidebarAvatar = document.getElementById('sidebar-avatar');
        const homeAvatar = document.getElementById('home-avatar');

        if (equippedId && rendersMap[equippedId]) {
            const renderUrl = rendersMap[equippedId];
            sidebarAvatar.style.backgroundImage = `url('${renderUrl}')`;
            homeAvatar.src = renderUrl;
        } else {
            sidebarAvatar.style.backgroundImage = `url('${defaultImg}')`;
            homeAvatar.src = defaultImg;
        }
    };
</script>

</body>
</html>