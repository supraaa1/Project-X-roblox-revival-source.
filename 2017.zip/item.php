<?php
// 1. Configuración de errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'db.php';

// Verificación de sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$username = $_SESSION['username'];
$user_id = $_SESSION['user_id']; 

// 2. Obtener ID del item
$item_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

try {
    // --- NUEVO: Obtener estado verificado del usuario de la sesión ---
    $stmt_me = $pdo->prepare("SELECT is_verified FROM users WHERE id = ?");
    $stmt_me->execute([$user_id]);
    $my_user_data = $stmt_me->fetch();
    $is_me_verified = ($my_user_data && $my_user_data['is_verified'] == 1);

    // Consulta del item con JOIN y nuevos campos de tiempo/estado
    $stmt = $pdo->prepare("
        SELECT catalog_items.*, users.username AS creator_name, users.is_verified AS creator_verified 
        FROM catalog_items 
        LEFT JOIN users ON catalog_items.creator_id = users.id 
        WHERE catalog_items.id = ?
    ");
    $stmt->execute([$item_id]);
    $item = $stmt->fetch();

    if (!$item) {
        die("Item no encontrado.");
    }

    // --- LÓGICA DE SALES (Contar en la tabla inventory) ---
    $stmt_sales = $pdo->prepare("SELECT COUNT(*) FROM inventory WHERE item_id = ?");
    $stmt_sales->execute([$item_id]);
    $sales_count = $stmt_sales->fetchColumn();

    // --- LÓGICA DE STOCK LIMITADO ---
    $current_price = $item['price'];
    $remaining_stock = null;
    $is_sold_out = false;

    if (isset($item['stock']) && $item['stock'] > 0) {
        $remaining_stock = $item['stock'] - $sales_count;
        if ($remaining_stock <= 0) {
            $remaining_stock = 0;
            $is_sold_out = true;
            if (isset($item['afterstock_price']) && !empty($item['afterstock_price'])) {
                $current_price = $item['afterstock_price'];
            }
        }
    }

    // --- LÓGICA DE TIEMPO Y ESTADO OFF-SALE ---
    $time_left = 0;
    $is_offsale_db = isset($item['is_offsale']) ? $item['is_offsale'] : 0;
    $offsale_at_db = isset($item['offsale_at']) ? $item['offsale_at'] : null;

    if ($offsale_at_db) {
        $expiry = strtotime($offsale_at_db);
        $now = time();
        $time_left = $expiry - $now;
        
        if ($time_left <= 0) {
            $is_offsale_db = 1;
            $time_left = 0;
        }
    }

    // --- Verificar si el usuario ya tiene el item ---
    $stmt_owned = $pdo->prepare("SELECT id FROM inventory WHERE user_id = ? AND item_id = ?");
    $stmt_owned->execute([$user_id, $item_id]);
    $is_owned = $stmt_owned->fetch() ? true : false;

    // Consulta para saldo del usuario
    $stmt_u = $pdo->prepare("SELECT robux FROM users WHERE id = ?");
    $stmt_u->execute([$user_id]);
    $user_balance = $stmt_u->fetch();

    // 3. Consulta para Items Recomendados
    $stmt_rec = $pdo->query("SELECT * FROM catalog_items WHERE id != $item_id ORDER BY RAND() LIMIT 7");
    $recommended = $stmt_rec->fetchAll();

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($item['name']); ?> - Project X</title>

    <meta property="og:title" content="<?php echo htmlspecialchars($item['name']); ?>" />
    <meta property="og:description" content="Price: R$ <?php echo number_format($current_price); ?> | Creator: <?php echo htmlspecialchars($item['creator_name'] ?? 'ROBLOX'); ?> | <?php echo htmlspecialchars(substr($item['description'], 0, 100)); ?>..." />
    <meta property="og:image" content="<?php echo htmlspecialchars($item['thumbnail']); ?>" />
    <meta property="og:type" content="https://projectx.xo.je" />
    <meta name="theme-color" content="#00A2FF">

    <style>
        :root {
            --rbx-blue: #00A2FF;
            --rbx-bg: #E3E3E3;
            --text-main: #393B3D;
            --border-light: #CCC;
        }

        body {
            margin: 0; padding: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            background-color: var(--rbx-bg);
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: 180px;
            background: white;
            height: calc(100vh - 40px);
            position: fixed;
            top: 40px;
            border-right: 1px solid #CCC;
            padding: 0;
            z-index: 1001;
        }
        .sidebar-user {
            padding: 10px 15px;
            display: flex;
            align-items: center;
            gap: 8px;
            border-bottom: 1px solid #E3E3E3;
            margin-bottom: 5px;
        }
        .sidebar-user-img {
            width: 28px; height: 28px;
            background-color: #EEE;
            background-image: url('avatar.png');
            background-size: cover;
            background-position: center;
            border-radius: 50%;
            border: 1px solid #CCC;
            flex-shrink: 0;
        }
        .sidebar-user-name {
            font-size: 16px; font-weight: 500;
            color: var(--text-main);
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .sidebar-item {
            padding: 8px 15px;
            display: flex; align-items: center;
            text-decoration: none; color: var(--text-main);
            font-size: 16px; transition: background 0.1s;
        }
        .sidebar-item:hover { background-color: #F2F2F2; }
        .sidebar-icon-container { width: 24px; height: 24px; margin-right: 12px; display: flex; align-items: center; justify-content: center; }
        .sidebar-icon { width: 22px; height: 22px; fill: none; stroke: #232527; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
        .nav-badge { margin-left: auto; background-color: var(--rbx-blue); color: white; font-size: 11px; font-weight: bold; padding: 2px 6px; border-radius: 10px; }
        .btn-upgrade-container { padding: 10px; margin-top: 5px; }
        .btn-upgrade { background-color: var(--rbx-blue); color: white; border: none; padding: 10px; width: 100%; border-radius: 4px; font-weight: bold; font-size: 15px; cursor: pointer; text-align: center; }

        .stock-info {
            background: #f8f9fa;
            border: 1px solid #ddd;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            border-left: 4px solid var(--rbx-blue);
        }
        .stock-count { color: #d9534f; font-weight: bold; }

        .main-container {
            margin-left: 180px;
            padding-top: 60px;
            display: flex;
            justify-content: center;
        }
        .item-layout { width: 1000px; display: flex; gap: 20px; padding: 20px; }
        
        .item-card-main { background: white; border: 1px solid #CCC; flex-grow: 1; display: flex; flex-direction: column; }
        .item-details-upper { display: flex; padding: 20px; position: relative; }
        .item-image-box { width: 350px; display: flex; flex-direction: column; align-items: center; }
        .main-img { width: 300px; height: 300px; object-fit: contain; }
        .favorite-count { align-self: flex-start; margin-top: 10px; color: #777; font-size: 14px; display: flex; align-items: center; gap: 5px; }

        .item-info-box { flex-grow: 1; padding-left: 30px; position: relative; }
        .item-title { font-size: 28px; font-weight: bold; margin: 0; color: #393B3D; }
        .item-creator { font-size: 14px; color: #777; margin: 5px 0 20px 0; display: flex; align-items: center; gap: 4px; }
        .item-creator span { color: var(--rbx-blue); cursor: pointer; }

        .details-grid { display: grid; grid-template-columns: 100px 1fr; gap: 10px; font-size: 14px; color: #393B3D; }
        .label { color: #777; }
        .price-text { color: #008140; font-weight: bold; font-size: 18px; display: flex; align-items: center; gap: 5px; }
        .robux-img { width: 20px; height: 20px; }

        .buy-button {
            background-color: #00B050; color: white; border: none;
            padding: 10px 40px; font-size: 18px; font-weight: bold;
            border-radius: 3px; cursor: pointer; position: absolute; top: 60px; right: 20px;
        }
        .buy-button.owned { background-color: #BDC3C7; color: #7F8C8D; cursor: default; }
        .buy-button.offsale { background-color: #666 !important; cursor: not-allowed; opacity: 0.7; }

        .description-text { margin-top: 10px; line-height: 1.4; color: #555; }

        .timer-container {
            display: flex; align-items: center; background: #FFF3CD;
            border: 1px solid #FFEeba; padding: 8px 12px; margin-bottom: 15px;
            border-radius: 4px; color: #856404; font-weight: bold; gap: 10px;
        }
        .timer-logo { width: 20px; height: 20px; border: 2px solid #856404; border-radius: 50%; position: relative; }
        .timer-logo::after {
            content: ''; position: absolute; width: 2px; height: 8px; background: #856404;
            left: 9px; top: 2px; transform-origin: bottom; animation: clock-spin 2s linear infinite;
        }
        @keyframes clock-spin { 100% { transform: rotate(360deg); } }

        .recommended-section { background: #E1E1E1; padding: 10px 20px; border-top: 1px solid #CCC; }
        .recommended-title { font-size: 18px; font-weight: bold; margin-bottom: 10px; }
        .recommended-grid { display: flex; gap: 10px; overflow-x: auto; padding-bottom: 5px; }
        .rec-item { background: white; border: 1px solid #CCC; width: 110px; flex-shrink: 0; text-decoration: none; padding: 5px; transition: border 0.2s; }
        .rec-item:hover { border-color: var(--rbx-blue); }
        .rec-img { width: 100px; height: 100px; object-fit: contain; }

        .ad-column { width: 160px; }
        .ad-box { width: 160px; height: 600px; background: white; border: 1px solid #CCC; overflow: hidden; }
        .dots-menu { position: absolute; top: 15px; right: 15px; font-weight: bold; cursor: pointer; }

        /* --- MODAL --- */
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000; justify-content: center; align-items: center; }
        .modal-content { background: white; width: 400px; border-radius: 3px; box-shadow: 0 2px 10px rgba(0,0,0,0.3); overflow: hidden; }
        .modal-header { padding: 15px; border-bottom: 1px solid #EEE; display: flex; justify-content: space-between; }
        .modal-header h2 { margin: 0; font-size: 20px; color: #393B3D; }
        .modal-body { padding: 20px; text-align: center; }
        .modal-item-img { width: 150px; height: 150px; object-fit: contain; margin: 15px 0; }
        .modal-footer { padding: 15px; text-align: center; border-top: 1px solid #EEE; background: #F8F8F8; }
        .btn-modal-green { background: #00B050; color: white; border: none; padding: 10px 25px; font-weight: bold; cursor: pointer; border-radius: 3px; font-size: 16px; }
        .btn-modal-gray { background: white; color: #555; border: 1px solid #CCC; padding: 10px 25px; font-weight: bold; cursor: pointer; border-radius: 3px; font-size: 16px; margin-left: 10px; }
        
        /* Badge verificado */
        .verified-badge { width: 16px; height: 16px; vertical-align: middle; }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="sidebar">
    <div class="sidebar-user">
        <div class="sidebar-user-img"></div>
        <span class="sidebar-user-name"><?php echo htmlspecialchars($username); ?></span>
        <?php if ($is_me_verified): ?>
            <img src="verified.png" class="verified-badge" title="Verified">
        <?php endif; ?>
    </div>

    <a href="home.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
        </div>
        Home
    </a>
    <a href="profile.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
        </div>
        Profile
    </a>
    <a href="messages.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        </div>
        Messages
    </a>
    <a href="friends.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        </div>
        Friends <span class="nav-badge">0</span>
    </a>
    <a href="avatar.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M12 2a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zM9 22V12h6v10M4 7h16M4 7l2 5h12l2-5"></path></svg>
        </div>
        Avatar
    </a>
    <a href="inventory.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
        </div>
        Inventory
    </a>
    <a href="trade.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><polyline points="16 3 21 3 21 8"></polyline><line x1="4" y1="20" x2="21" y2="3"></line><polyline points="21 16 21 21 16 21"></polyline><line x1="15" y1="15" x2="21" y2="21"></line><line x1="4" y1="4" x2="9" y2="9"></line></svg>
        </div>
        Trade
    </a>
    <div class="btn-upgrade-container">
        <button class="btn-upgrade">Upgrade Now</button>
    </div>
</div>

<div class="main-container">
    <div class="item-layout">
        <div class="item-card-main">
            <div class="item-details-upper">
                <div class="dots-menu">...</div>
                <div class="item-image-box">
                    <img src="<?php echo htmlspecialchars($item['thumbnail']); ?>" class="main-img" onerror="this.src='default.png'">
                    <div class="favorite-count"><span style="color:#FFD700; font-size:20px;">☆</span> 0</div>
                </div>

                <div class="item-info-box">
                    <h1 class="item-title"><?php echo htmlspecialchars($item['name']); ?></h1>
                    <div class="item-creator">
                        By <span><?php echo htmlspecialchars($item['creator_name'] ?? 'ROBLOX'); ?></span>
                        <?php if (isset($item['creator_verified']) && $item['creator_verified'] == 1): ?>
                            <img src="verified.png" class="verified-badge" title="Verified Creator">
                        <?php endif; ?>
                    </div>

                    <?php if ($remaining_stock !== null): ?>
                        <div class="stock-info">
                            <span style="font-size: 13px; color: #555;">Limited Item:</span><br>
                            <?php if ($remaining_stock > 0): ?>
                                Copies: <span class="stock-count"><?php echo number_format($remaining_stock); ?></span> / <?php echo number_format($item['stock']); ?>
                            <?php else: ?>
                                <span class="stock-count">NEW ITEM DROPPED!</span> 
                                <?php if (!empty($item['afterstock_price'])): ?>
                                    <span style="font-size: 11px; color: #777; font-style: italic;"> (:d)</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($offsale_at_db && $time_left > 0 && $is_offsale_db == 0): ?>
                        <div class="timer-container" id="timerDisplay">
                            <div class="timer-logo"></div>
                            <span>Offsale in: <span id="countdown">--:--:--</span></span>
                        </div>
                    <?php endif; ?>

                    <div class="details-grid">
                        <div class="label">Price</div>
                        <div class="price-text">
                            <img src="robux.png" class="robux-img">
                            <?php echo number_format($current_price); ?>
                        </div>
                        <div class="label">Type</div>
                        <div><?php echo htmlspecialchars(!empty($item['type']) ? $item['type'] : 'Package'); ?></div>
                        <div class="label">Sales</div>
                        <div><?php echo number_format($sales_count); ?></div>
                        <div class="label">Created</div>
                        <div>4/26/2026</div>
                        <div class="label">Genres</div>
                        <div style="color:var(--rbx-blue)">All</div>
                        <div class="label">Description</div>
                        <div class="description-text">
                            <?php echo nl2br(htmlspecialchars($item['description'] ?? 'No description available.')); ?>
                        </div>
                    </div>

                    <?php if ($is_offsale_db == 1): ?>
                        <button class="buy-button offsale" disabled>Offsale</button>
                    <?php elseif ($is_owned): ?>
                        <button class="buy-button owned">Owned</button>
                    <?php else: ?>
                        <button class="buy-button" id="buyBtn" onclick="openPurchaseModal()">Buy</button>
                    <?php endif; ?>
                </div>
            </div>

            <div class="recommended-section">
                <div class="recommended-title">Recommended Items</div>
                <div class="recommended-grid">
                    <?php foreach ($recommended as $rec): ?>
                        <a href="item.php?id=<?php echo $rec['id']; ?>" class="rec-item">
                            <img src="<?php echo htmlspecialchars($rec['thumbnail']); ?>" class="rec-img" onerror="this.src='default.png'">
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="ad-column">
            <div class="ad-box">
                <img src="https://devforum-uploads.s3.dualstack.us-east-2.amazonaws.com/uploads/original/4X/6/d/9/6d93234c805abb90035253d7a4e542979ebb8af8.png" style="width:100%; height:100%; object-fit:cover;">
            </div>
        </div>
    </div>
</div>

<div id="purchaseModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Buy Item</h2>
            <span style="cursor:pointer; font-weight:bold; color:#CCC;" onclick="closeModal()">&times;</span>
        </div>
        <div class="modal-body" id="modalBody">
            <p style="text-align:left; color:#555;">
                Would you like to buy the <?php echo htmlspecialchars($item['type'] ?? 'Item'); ?> "<strong><?php echo htmlspecialchars($item['name']); ?></strong>" from 
                <strong><?php echo htmlspecialchars($item['creator_name'] ?? 'ROBLOX'); ?></strong>
                <?php if (isset($item['creator_verified']) && $item['creator_verified'] == 1): ?>
                    <img src="verified.png" class="verified-badge">
                <?php endif; ?>
                for <img src="robux.png" style="width:15px; vertical-align:middle;"> <?php echo number_format($current_price); ?>?
            </p>
            <img src="<?php echo htmlspecialchars($item['thumbnail']); ?>" class="modal-item-img" onerror="this.src='default.png'">
        </div>
        <div class="modal-footer" id="modalFooter">
            <button class="btn-modal-green" onclick="confirmPurchase()">Buy Now</button>
            <button class="btn-modal-gray" onclick="closeModal()">Cancel</button>
            <div style="font-size: 12px; color: #777; margin-top: 10px;">
                Your balance after this transaction will be <img src="robux.png" style="width:12px;"> 
                <?php echo number_format($user_balance['robux'] - $current_price); ?>
            </div>
        </div>
    </div>
</div>

<script>
function openPurchaseModal() {
    <?php if ($is_owned || $is_offsale_db == 1): ?>
        return;
    <?php endif; ?>
    document.getElementById('purchaseModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('purchaseModal').style.display = 'none';
}

function confirmPurchase() {
    const modalBody = document.getElementById('modalBody');
    const modalFooter = document.getElementById('modalFooter');
    modalFooter.innerHTML = "Processing...";
    
    fetch('buy.php?id=<?php echo $item_id; ?>&currency=robux')
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            modalBody.innerHTML = "<h3>Purchase Complete!</h3><p>You have successfully bought the item.</p>";
            modalFooter.innerHTML = '<button class="btn-modal-green" onclick="location.reload()">OK</button>';
        } else {
            modalBody.innerHTML = "<h3>Error</h3><p>" + (data.message || "Insufficient funds.") + "</p>";
            modalFooter.innerHTML = '<button class="btn-modal-gray" onclick="closeModal()">Close</button>';
        }
    })
    .catch(error => {
        modalBody.innerHTML = "<h3>Error</h3><p>Server error. Try again.</p>";
        modalFooter.innerHTML = '<button class="btn-modal-gray" onclick="closeModal()">Close</button>';
    });
}

<?php if ($offsale_at_db && $time_left > 0): ?>
    let secondsLeft = <?php echo $time_left; ?>;
    const countdownEl = document.getElementById('countdown');
    const buyBtn = document.getElementById('buyBtn');

    function updateTimer() {
        if (secondsLeft <= 0) {
            countdownEl.innerHTML = "00:00:00";
            if(buyBtn) {
                buyBtn.innerHTML = "Offsale";
                buyBtn.classList.add('offsale');
                buyBtn.disabled = true;
                buyBtn.onclick = null;
            }
            return;
        }

        const h = Math.floor(secondsLeft / 3600);
        const m = Math.floor((secondsLeft % 3600) / 60);
        const s = secondsLeft % 60;

        countdownEl.innerHTML = 
            (h < 10 ? "0"+h : h) + ":" + 
            (m < 10 ? "0"+m : m) + ":" + 
            (s < 10 ? "0"+s : s);
        
        secondsLeft--;
    }

    setInterval(updateTimer, 1000);
    updateTimer();
<?php endif; ?>
</script>

</body>
</html>