<?php
// 1. Mostrar errores para depurar
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// 2. Importar tu conexión PDO
require_once 'db.php';

// Verificación de sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$username = $_SESSION['username'];

// 3. Consulta usando PDO
try {
    $stmt = $pdo->query("SELECT * FROM catalog_items ORDER BY id DESC");
    $items = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_msg = "Error en la base de datos: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Catalog - Project X</title>
    <style>
        :root {
            --rbx-blue: #00A2FF;
            --rbx-bg: #E3E3E3;
            --text-main: #393B3D;
            --border-light: #CCC;

            /* AJUSTES DE LIMITED.PNG */
            --limited-size: 65px;   /* Cambia el tamaño aquí */
            --limited-bottom: 2px; /* Mover arriba/abajo (ej: 10px sube) */
            --limited-left: 1px;   /* Mover izquierda/derecha */
        }

        body {
            margin: 0;
            padding: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            background-color: var(--rbx-bg);
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: 180px;
            background: white;
            height: calc(100vh - 40px);
            position: fixed;
            top: 40px;
            border-right: 1px solid #CCC;
            padding: 0;
            z-index: 1001;
        }

        .sidebar-user {
            padding: 10px 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid #E3E3E3;
            margin-bottom: 5px;
        }

        .sidebar-user-img {
            width: 28px; height: 28px;
            background-color: #EEE;
            background-image: url('avatar.png');
            background-size: cover;
            background-position: center;
            border-radius: 50%;
            border: 1px solid #CCC;
        }

        .sidebar-user-name {
            font-size: 16px; font-weight: 500;
            color: var(--text-main);
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }

        .sidebar-item {
            padding: 8px 15px;
            display: flex; align-items: center;
            text-decoration: none;
            color: var(--text-main);
            font-size: 14px;
            transition: background 0.1s;
        }

        .sidebar-item:hover { background-color: #F2F2F2; }

        .sidebar-icon-container {
            width: 24px; height: 24px;
            margin-right: 12px;
            display: flex; align-items: center; justify-content: center;
        }

        .sidebar-icon {
            width: 18px; height: 18px;
            fill: none; stroke: #232527;
            stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
        }

        .nav-badge {
            margin-left: auto;
            background-color: var(--rbx-blue);
            color: white; font-size: 11px; font-weight: bold;
            padding: 2px 6px; border-radius: 10px;
        }

        /* --- CONTENEDOR PRINCIPAL --- */
        .main-container {
            margin-left: 180px;
            padding-top: 90px; 
            display: flex;
            justify-content: center;
            min-height: 100vh;
        }

        .catalog-layout {
            width: 1100px;
            display: flex;
            gap: 15px;
            padding: 0 20px;
        }

        /* Filtros Izquierda */
        .filters-sidebar {
            width: 160px;
            flex-shrink: 0;
        }

        .filter-group { margin-bottom: 20px; }
        .filter-title { font-size: 18px; font-weight: bold; margin-bottom: 10px; }
        .filter-sub { font-size: 14px; color: #555; margin-bottom: 5px; cursor: pointer; }
        .filter-sub:hover { color: var(--rbx-blue); }
        .filter-item { font-size: 13px; color: #777; padding-left: 10px; margin-bottom: 4px; }

        /* Area Central */
        .catalog-main { flex-grow: 1; }

        /* Buscador Superior */
        .catalog-top-bar {
            background: #E1E1E1;
            padding: 10px;
            display: flex;
            gap: 10px;
            align-items: center;
            border: 1px solid #CCC;
            margin-bottom: 15px;
        }

        .search-input {
            flex-grow: 1;
            padding: 6px 10px;
            border: 1px solid #B8B8B8;
        }

        .category-select {
            padding: 5px;
            border: 1px solid #B8B8B8;
            background: white;
            min-width: 120px;
        }

        /* --- GRID AJUSTADO A LA IMAGEN --- */
        .item-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            gap: 12px;
        }

        .item-card {
            background: white;
            border: 1px solid #CCC;
            border-radius: 3px;
            text-decoration: none;
            color: #333;
            position: relative;
            display: flex;
            flex-direction: column;
            transition: box-shadow 0.1s;
        }

        .item-card:hover {
            box-shadow: 0 1px 4px rgba(0,0,0,0.2);
        }

        .thumb-box {
            width: 100%;
            aspect-ratio: 1/1;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            padding: 5px;
            box-sizing: border-box;
        }

        .item-img { max-width: 90%; max-height: 90%; object-fit: contain; }

        /* MODIFICACIÓN DE POSICIÓN Y TAMAÑO */
        .limited-tag {
            position: absolute;
            bottom: var(--limited-bottom);
            left: var(--limited-left);
            width: var(--limited-size);
            height: auto;
            z-index: 5;
        }

        /* ESTILOS OFFSALE Y TIMER */
        .offsale-label {
            position: absolute;
            top: 5px;
            left: 5px;
            background: rgba(0,0,0,0.7);
            color: white;
            font-size: 10px;
            padding: 2px 5px;
            font-weight: bold;
            text-transform: uppercase;
            border-radius: 2px;
            z-index: 10;
        }

        .timer-tag {
            position: absolute;
            top: 5px;
            right: 5px;
            background: #FFF3CD;
            border: 1px solid #FFEeba;
            color: #856404;
            font-size: 10px;
            padding: 2px 5px;
            font-weight: bold;
            border-radius: 2px;
            display: flex;
            align-items: center;
            gap: 3px;
            z-index: 10;
        }

        .item-info {
            padding: 8px;
            border-top: 1px solid #EEE;
            font-size: 14px;
        }

        .item-name {
            color: #005587; /* Azul del catálogo 2016 */
            font-weight: 400;
            height: 36px;
            overflow: hidden;
            margin-bottom: 8px;
            line-height: 1.2;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }

        .item-price-row {
            display: flex;
            align-items: center;
            gap: 4px;
            color: #008140;
            font-weight: bold;
        }

        .item-price-row.is-offsale {
            color: #777;
        }

        .robux-img {
            width: 16px;
            height: 16px;
        }

        /* ESTILO PARA EL STOCK */
        .item-stock {
            font-size: 11px;
            color: #777;
            margin-top: 4px;
            font-weight: normal;
        }

        /* Banner de la derecha */
        .ad-column {
            width: 160px;
            flex-shrink: 0;
        }

        .ad-box {
            width: 160px;
            height: 600px;
            background: #CCC;
            border: 1px solid #AAA;
            overflow: hidden;
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="sidebar">
    <div class="sidebar-user">
        <div class="sidebar-user-img"></div>
        <span class="sidebar-user-name"><?php echo htmlspecialchars($username); ?></span>
    </div>

    <a href="home.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
        </div> Home
    </a>
    <a href="profile.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
        </div> Profile
    </a>
    <a href="catalog.php" class="sidebar-item" style="font-weight:bold; background:#F2F2F2;">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24" style="stroke:var(--rbx-blue)"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
        </div> Catalog
    </a>
    <a href="messages.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        </div> Messages
    </a>
    <a href="friends.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
        </div> Friends <span class="nav-badge">0</span>
    </a>
    <a href="avatar.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M12 2a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3z"></path><path d="M9 22V12h6v10"></path></svg>
        </div> Avatar
    </a>
    <a href="inventory.php" class="sidebar-item">
        <div class="sidebar-icon-container">
            <svg class="sidebar-icon" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect></svg>
        </div> Inventory
    </a>
</div>

<div class="main-container">
    <div class="catalog-layout">
        
        <div class="filters-sidebar">
            <h1 style="font-size:32px; margin:0 0 10px 0;">Catalog</h1>
            <div class="filter-group">
                <div class="filter-title">Category</div>
                <div class="filter-sub">All Categories</div>
                <div class="filter-sub" style="color:var(--rbx-blue); font-weight:bold;">Featured</div>
                <div class="filter-item">All Featured Items</div>
                <div class="filter-item">Accessories</div>
                <div class="filter-title" style="margin-top:15px;">Filters</div>
                <div class="filter-sub">Genre</div>
                <label class="filter-item" style="display:block;"><input type="checkbox"> Horror</label>
                <label class="filter-item" style="display:block;"><input type="checkbox"> Town and City</label>
            </div>
        </div>

        <div class="catalog-main">
            <div class="catalog-top-bar">
                <input type="text" class="search-input" placeholder="Search">
                <select class="category-select">
                    <option>Featured</option>
                    <option>Collectibles</option>
                </select>
                <button style="padding: 5px 10px; cursor:pointer;">Search</button>
            </div>

            <div style="font-size: 13px; color: #555; margin-bottom: 15px;">
                Featured > All Categories <br>
                <span style="font-weight:bold;">1 - <?php echo count($items); ?> Results</span>
            </div>

            <div class="item-grid">
                <?php if (!empty($items)): ?>
                    <?php foreach ($items as $row): 
                        // Lógica de estado Offsale y Timer
                        $is_offsale = (isset($row['is_offsale']) && $row['is_offsale'] == 1);
                        $time_left = 0;
                        if (isset($row['offsale_at']) && $row['offsale_at']) {
                            $time_left = strtotime($row['offsale_at']) - time();
                            if ($time_left <= 0) {
                                $is_offsale = true;
                                $time_left = 0;
                            }
                        }
                    ?>
                        <a href="item.php?id=<?php echo $row['id']; ?>" class="item-card">
                            <div class="thumb-box">
                                <?php if ($is_offsale): ?>
                                    <div class="offsale-label"></div>
                                <?php elseif ($time_left > 0): ?>
                                    <div class="timer-tag" data-seconds="<?php echo $time_left; ?>">
                                        ⏱ <span class="cd-text">--:--</span>
                                    </div>
                                <?php endif; ?>

                                <?php if (isset($row['is_limited']) && $row['is_limited'] == 1): ?>
                                    <img src="limited.png" class="limited-tag">
                                <?php endif; ?>
                                <img src="<?php echo htmlspecialchars($row['thumbnail']); ?>" class="item-img" onerror="this.src='default.png'">
                            </div>
                            
                            <div class="item-info">
                                <div class="item-name"><?php echo htmlspecialchars($row['name']); ?></div>
                                <div class="item-price-row <?php echo $is_offsale ? 'is-offsale' : ''; ?>">
                                    <?php if ($is_offsale): ?>
                                        <span>Offsale</span>
                                    <?php else: ?>
                                        <img src="robux.png" class="robux-img">
                                        <span><?php echo number_format($row['price'] ?? 0); ?></span>
                                    <?php endif; ?>
                                </div>
                                <!-- MUESTRA EL STOCK SI ES LIMITED -->
                                <?php if (isset($row['is_limited']) && $row['is_limited'] == 1 && isset($row['stock'])): ?>
                                    <div class="item-stock">Remaining: <?php echo number_format($row['stock']); ?></div>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No items found.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="ad-column">
            <div class="ad-box">
                <img src="https://devforum-uploads.s3.dualstack.us-east-2.amazonaws.com/uploads/original/4X/6/d/9/6d93234c805abb90035253d7a4e542979ebb8af8.png" style="width:100%; height:100%; object-fit:cover;">
            </div>
        </div>

    </div>
</div>

<script>
// Script para manejar múltiples timers en el catálogo
function startCatalogTimers() {
    const timerTags = document.querySelectorAll('.timer-tag');
    
    timerTags.forEach(tag => {
        let seconds = parseInt(tag.getAttribute('data-seconds'));
        const textSpan = tag.querySelector('.cd-text');
        
        const update = () => {
            if (seconds <= 0) {
                location.reload(); // Recargar para mostrar "Offsale"
                return;
            }
            
            const h = Math.floor(seconds / 3600);
            const m = Math.floor((seconds % 3600) / 60);
            const s = seconds % 60;
            
            textSpan.innerText = 
                (h > 0 ? h + ":" : "") + 
                (m < 10 ? "0" + m : m) + ":" + 
                (s < 10 ? "0" + s : s);
            
            seconds--;
        };
        
        update();
        setInterval(update, 1000);
    });
}

window.addEventListener('load', startCatalogTimers);
</script>

</body>
</html>