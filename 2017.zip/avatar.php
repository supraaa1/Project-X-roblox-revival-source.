<?php

session_start();

require_once 'db.php';



if (!isset($_SESSION['user_id'])) {

    header("Location: index.php");

    exit();

}



$user_id = $_SESSION['user_id'];

$username = $_SESSION['username'];



// --- LÓGICA PARA VERIFICADO ---

$stmt_user = $pdo->prepare("SELECT is_verified FROM users WHERE id = ?");

$stmt_user->execute([$user_id]);

$user_data = $stmt_user->fetch();

$is_verified = ($user_data && $user_data['is_verified'] == 1);

// ------------------------------



$category = isset($_GET['category']) ? $_GET['category'] : 'Recent';



// Definimos la skin por defecto en una variable para no repetir avatar.png

$default_avatar = "avatar.png";



try {

    // Consulta para el inventario

    $query = "

        SELECT ci.* FROM inventory inv

        JOIN catalog_items ci ON inv.item_id = ci.id

        WHERE inv.user_id = ?

    ";

    

    if ($category !== 'Recent' && $category !== 'All') {

        $query .= " AND ci.type = ?";

        $stmt = $pdo->prepare($query);

        $stmt->execute([$user_id, $category]);

    } else {

        $stmt = $pdo->prepare($query);

        $stmt->execute([$user_id]);

    }

    $user_inventory = $stmt->fetchAll();



    // Obtener el mapa de Renders

    $stmt_renders = $pdo->query("SELECT item_id, render_url FROM fake_renders");

    $renders_map = $stmt_renders->fetchAll(PDO::FETCH_KEY_PAIR); 



} catch (PDOException $e) {

    die("Error: " . $e->getMessage());

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Avatar Editor - Project X</title>

    <style>

        :root {

            --rbx-blue: #00A2FF;

            --rbx-bg: #E3E3E3;

            --text-main: #393B3D;

            --rbx-green: #00B050;

        }



        body {

            margin: 0; padding: 0;

            font-family: "Segoe UI", Arial, sans-serif;

            background-color: var(--rbx-bg);

        }



        /* --- SIDEBAR --- */

        .sidebar {

            width: 180px;

            background: white;

            height: calc(100vh - 40px);

            position: column;

            position: fixed;

            top: 40px;

            border-right: 1px solid #CCC;

            padding: 0;

            z-index: 1001;

        }



        .sidebar-user {

            padding: 10px 15px;

            display: flex;

            align-items: center;

            gap: 10px;

            border-bottom: 1px solid #E3E3E3;

            margin-bottom: 5px;

        }



        .sidebar-user-img {

            width: 28px;

            height: 28px;

            background-color: #EEE;

            background-image: url('<?php echo $default_avatar; ?>');

            background-size: cover;

            background-position: center;

            border-radius: 50%;

            border: 1px solid #CCC;

        }



        .sidebar-user-name {

            font-size: 16px;

            font-weight: 500;

            color: var(--text-main);

            white-space: nowrap;

            overflow: hidden;

            text-overflow: ellipsis;

            display: flex;

            align-items: center;

        }



        .verified-icon {

            width: 16px;

            height: 16px;

            margin-left: 5px;

            flex-shrink: 0;

            object-fit: contain;

        }



        .sidebar-item {

            padding: 8px 15px;

            display: flex;

            align-items: center;

            text-decoration: none;

            color: var(--text-main);

            font-size: 16px;

            transition: background 0.1s;

        }



        .sidebar-item:hover { background-color: #F2F2F2; }

        

        .sidebar-icon-container {

            width: 24px; height: 24px;

            margin-right: 12px;

            display: flex; align-items: center; justify-content: center;

        }



        .sidebar-icon {

            width: 22px; height: 22px;

            fill: none; stroke: #232527;

            stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;

        }



        /* --- CONTENEDOR PRINCIPAL --- */

        .main-container {

            margin-left: 180px; 

            padding-top: 60px;

            display: flex;

            justify-content: center;

        }



        .avatar-wrapper {

            width: 1000px;

            background: white;

            display: flex;

            min-height: 85vh;

            border: 1px solid #CCC;

            box-shadow: 0 1px 3px rgba(0,0,0,0.1);

        }



        .editor-left {

            width: 380px;

            padding: 20px;

            border-right: 1px solid #EEE;

        }



        .render-box {

            width: 100%;

            height: 380px;

            background: #fff;

            border: 1px solid #DDD;

            position: relative;

            display: flex;

            align-items: center;

            justify-content: center;

            overflow: hidden;

        }



        /* --- LOADING SPINNER --- */

        .loader {

            display: none;

            position: absolute;

            width: 50px;

            height: 50px;

            border: 5px solid #f3f3f3;

            border-top: 5px solid var(--rbx-blue);

            border-radius: 50%;

            animation: spin 1s linear infinite;

            z-index: 10;

        }



        @keyframes spin {

            0% { transform: rotate(0deg); }

            100% { transform: rotate(360deg); }

        }



        .toggle-r6-r15 {

            position: absolute;

            top: 10px; right: 10px;

            background: #FFF; border: 1px solid #CCC;

            border-radius: 15px; display: flex; font-size: 11px;

            z-index: 5;

        }



        .toggle-btn { padding: 4px 10px; cursor: pointer; color: #777; font-weight: bold; }

        .toggle-btn.active { background: var(--rbx-blue); color: white; border-radius: 12px; }



        .scaling-section { margin-top: 20px; }

        .scaling-row { margin-bottom: 15px; }

        .scaling-label { display: flex; justify-content: space-between; font-size: 14px; margin-bottom: 5px; }

        .scaling-slider { width: 100%; accent-color: var(--rbx-blue); cursor: pointer; }



        .inventory-right { flex-grow: 1; display: flex; flex-direction: column; }



        .inventory-top {

            background: #F2F2F2; padding: 10px 20px;

            display: flex; justify-content: flex-end; align-items: center; gap: 10px;

        }



        .btn-get-more { background: var(--rbx-green); color: white; padding: 6px 15px; text-decoration: none; border-radius: 3px; font-weight: bold; font-size: 13px; }



        .inventory-tabs { display: flex; border-bottom: 1px solid #DDD; background: #fff; }

        .tab { padding: 12px 20px; cursor: pointer; color: #666; text-decoration: none; border-bottom: 3px solid transparent; font-size: 15px; }

        .tab.active { border-bottom: 3px solid var(--rbx-blue); color: var(--rbx-blue); }



        .items-grid {

            padding: 20px;

            display: grid;

            grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));

            gap: 15px;

        }



        .item-card { 

            border: 1px solid #EEE; 

            padding: 8px; 

            text-align: center; 

            cursor: pointer; 

            transition: all 0.2s;

            background: white;

            position: relative;

        }

        

        .item-card:hover { border-color: #AAA; }

        

        .item-card.equipped {

            border: 2px solid var(--rbx-green) !important;

            background-color: #EFFFF4;

        }



        .item-img { width: 90px; height: 90px; object-fit: contain; pointer-events: none; }

        .item-name { font-size: 12px; margin-top: 5px; color: #333; pointer-events: none; }

    </style>

</head>

<body>



<?php include 'header.php'; ?>



<div class="sidebar">

    <div class="sidebar-user">

        <div class="sidebar-user-img"></div>

        <span class="sidebar-user-name">

            <?php echo htmlspecialchars($username); ?>

            <?php if ($is_verified): ?>

                <img src="verified.png" class="verified-icon" alt="Verified">

            <?php endif; ?>

        </span>

    </div>



    <a href="home.php" class="sidebar-item">

        <div class="sidebar-icon-container">

            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>

        </div>

        Home

    </a>

    

    <a href="profile.php" class="sidebar-item">

        <div class="sidebar-icon-container">

            <svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>

        </div>

        Profile

    </a>



    <a href="avatar.php" class="sidebar-item" style="background:#F2F2F2;">

        <div class="sidebar-icon-container">

            <svg class="sidebar-icon" viewBox="0 0 24 24" style="stroke:var(--rbx-blue);"><path d="M12 2a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zM9 22V12h6v10M4 7h16M4 7l2 5h12l2-5"></path></svg>

        </div>

        <span style="color:var(--rbx-blue); font-weight:bold;">Avatar</span>

    </a>



    <a href="inventory.php" class="sidebar-item">

        <div class="sidebar-icon-container">

            <svg class="sidebar-icon" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>

        </div>

        Inventory

    </a>

</div>



<div class="main-container">

    <div class="avatar-wrapper">

        <div class="editor-left">

            <h1 style="font-size:24px; font-weight:normal; margin-bottom:15px;">Avatar Editor</h1>

            <div class="render-box" id="render-container">

                <div class="loader" id="avatar-loader"></div>

                <div class="toggle-r6-r15">

                    <div class="toggle-btn">R6</div>

                    <div class="toggle-btn active">R15</div>

                </div>

                <img id="character-render" src="<?php echo $default_avatar; ?>" style="width:100%; height:100%; object-fit:contain;">

            </div>



            <div class="scaling-section">

                <h2 style="font-size:22px; font-weight:500;">Scaling</h2>

                <div class="scaling-row">

                    <div class="scaling-label"><span>Height</span><span>90%</span></div>

                    <input type="range" class="scaling-slider" value="90">

                </div>

                <div class="scaling-row">

                    <div class="scaling-label"><span>Width</span><span>70%</span></div>

                    <input type="range" class="scaling-slider" value="70">

                </div>

            </div>

        </div>



        <div class="inventory-right">

            <div class="inventory-top">

                <span>Explore the catalog to find more clothes!</span>

                <a href="catalog.php" class="btn-get-more">Get More</a>

            </div>



            <div class="inventory-tabs">

                <a href="?category=Recent" class="tab <?php echo $category == 'Recent' ? 'active' : ''; ?>">Recent ⌵</a>

                <a href="?category=Clothing" class="tab <?php echo $category == 'Clothing' ? 'active' : ''; ?>">Clothing ⌵</a>

                <a href="?category=Body" class="tab <?php echo $category == 'Body' ? 'active' : ''; ?>">Body ⌵</a>

            </div>



            <div class="items-grid" id="inventory-grid">

                <?php foreach ($user_inventory as $item): ?>

                    <div class="item-card" data-item-id="<?php echo $item['id']; ?>" onclick="wearItem(this)">

                        <img src="<?php echo htmlspecialchars($item['thumbnail']); ?>" class="item-img">

                        <div class="item-name"><?php echo htmlspecialchars($item['name']); ?></div>

                    </div>

                <?php endforeach; ?>

                <?php if(empty($user_inventory)) echo "<p style='color:#999; padding: 20px;'>No items found.</p>"; ?>

            </div>

        </div>

    </div>

</div>



<script>

const rendersMap = <?php echo json_encode($renders_map); ?>;

const defaultAvatar = "<?php echo $default_avatar; ?>";



window.onload = function() {

    const equippedId = localStorage.getItem('equipped_item_id');

    if (equippedId) {

        const card = document.querySelector(`.item-card[data-item-id="${equippedId}"]`);

        if (card) {

            applyEquip(card, equippedId, false);

        }

    }

};



function wearItem(element) {

    const itemId = element.getAttribute('data-item-id');

    const isAlreadyEquipped = element.classList.contains('equipped');



    if (isAlreadyEquipped) {

        unequipWithLoading();

    } else {

        applyEquip(element, itemId, true);

    }

}



function applyEquip(element, itemId, showLoading) {

    const characterImg = document.getElementById('character-render');

    const loader = document.getElementById('avatar-loader');



    document.querySelectorAll('.item-card').forEach(card => card.classList.remove('equipped'));

    element.classList.add('equipped');

    localStorage.setItem('equipped_item_id', itemId);



    if (rendersMap[itemId]) {

        if (showLoading) {

            loader.style.display = 'block';

            characterImg.style.opacity = '0.3';

            

            setTimeout(() => {

                characterImg.src = rendersMap[itemId];

                characterImg.onload = () => {

                    loader.style.display = 'none';

                    characterImg.style.opacity = '1';

                };

            }, 800);

        } else {

            characterImg.src = rendersMap[itemId];

        }

    }

}



function unequipWithLoading() {

    const characterImg = document.getElementById('character-render');

    const loader = document.getElementById('avatar-loader');



    document.querySelectorAll('.item-card').forEach(card => card.classList.remove('equipped'));

    localStorage.removeItem('equipped_item_id');



    loader.style.display = 'block';

    characterImg.style.opacity = '0.3';



    setTimeout(() => {

        characterImg.src = defaultAvatar;

        characterImg.onload = () => {

            loader.style.display = 'none';

            characterImg.style.opacity = '1';

        };

    }, 800);

}

</script>



</body>

</html>