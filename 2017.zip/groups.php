<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }

$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'];

// --- LÓGICA DE USUARIO (SIDEBAR) ---
try {
    $stmt_user = $pdo->prepare("SELECT rank, is_verified FROM users WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user_data = $stmt_user->fetch();
    $user_rank = $user_data['rank'] ?? 'User';
    $is_verified = $user_data['is_verified'] ?? 0;
} catch (PDOException $e) {
    $user_rank = 'User';
    $is_verified = 0;
}

// Mapa de renders para el avatar del sidebar
try {
    $stmt_renders = $pdo->query("SELECT item_id, render_url FROM fake_renders");
    $renders_map = $stmt_renders->fetchAll(PDO::FETCH_KEY_PAIR); 
} catch (PDOException $e) {
    $renders_map = [];
}

// --- LÓGICA DE GRUPOS ---
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $group_id = (int)$_GET['id'];
} else {
    $stmt_first = $pdo->query("SELECT id FROM groups ORDER BY id ASC LIMIT 1");
    $first_group = $stmt_first->fetch();
    $group_id = $first_group ? (int)$first_group['id'] : 0;
}

$default_avatar = "avatar.png";

if (isset($_POST['join_group']) && $group_id > 0) {
    $check = $pdo->prepare("SELECT id FROM group_members WHERE group_id = ? AND user_id = ?");
    $check->execute([$group_id, $user_id]);
    if (!$check->fetch()) {
        $join = $pdo->prepare("INSERT INTO group_members (group_id, user_id, rank_name) VALUES (?, ?, 'Member')");
        $join->execute([$group_id, $user_id]);
        header("Location: groups.php?id=" . $group_id);
        exit();
    }
}

try {
    $stmt = $pdo->prepare("SELECT g.*, u.username AS owner_name, u.is_verified AS owner_verified 
                           FROM groups g 
                           JOIN users u ON g.owner_id = u.id 
                           WHERE g.id = ?");
    $stmt->execute([$group_id]);
    $group = $stmt->fetch();

    if (!$group) { 
        $stmt_fallback = $pdo->query("SELECT id FROM groups ORDER BY id ASC LIMIT 1");
        $fallback = $stmt_fallback->fetch();
        if ($fallback) { header("Location: groups.php?id=" . $fallback['id']); exit(); }
        else { die("No hay grupos creados."); }
    }

    $stmt_is_member = $pdo->prepare("SELECT rank_name FROM group_members WHERE group_id = ? AND user_id = ?");
    $stmt_is_member->execute([$group_id, $user_id]);
    $user_membership = $stmt_is_member->fetch();

    $sidebar_groups_list = $pdo->query("SELECT id, name, logo FROM groups ORDER BY id ASC LIMIT 15")->fetchAll();

    $stmt_members = $pdo->prepare("
        SELECT u.id, u.username, u.is_verified, gm.rank_name, 
        (SELECT render_url FROM fake_renders fr WHERE fr.item_id = u.id LIMIT 1) as user_render
        FROM group_members gm 
        JOIN users u ON gm.user_id = u.id 
        WHERE gm.group_id = ? 
        ORDER BY gm.joined_at DESC LIMIT 16
    ");
    $stmt_members->execute([$group_id]);
    $members = $stmt_members->fetchAll();

    $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM group_members WHERE group_id = ?");
    $stmt_count->execute([$group_id]);
    $member_count = $stmt_count->fetchColumn();

} catch (PDOException $e) { die("Error: " . $e->getMessage()); }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($group['name']); ?> - Groups</title>
    <style>
        :root {
            --rbx-blue: #00A2FF;
            --rbx-bg: #E3E3E3;
            --text-main: #393B3D;
            --rbx-admin-red: #d9534f;
            --border: #CCC;
        }

        body { margin: 0; padding: 0; font-family: "Segoe UI", Arial, sans-serif; background-color: var(--rbx-bg); }

        /* Estilo Sidebar */
        .sidebar {
            width: 180px; background: white; height: calc(100vh - 40px); position: fixed;
            top: 40px; border-right: 1px solid #CCC; padding: 0; z-index: 1001;
        }
        .sidebar-user { padding: 10px 15px; display: flex; align-items: center; gap: 10px; border-bottom: 1px solid #E3E3E3; margin-bottom: 5px; }
        .sidebar-user-img { width: 28px; height: 28px; background-color: #EEE; background-size: cover; background-position: center; border-radius: 50%; border: 1px solid #CCC; }
        .sidebar-user-name { font-size: 16px; font-weight: 500; color: var(--text-main); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: flex; align-items: center; gap: 4px; }
        .verified-badge { width: 16px; height: 16px; vertical-align: middle; }
        
        .sidebar-item { padding: 8px 15px; display: flex; align-items: center; text-decoration: none; color: var(--text-main); font-size: 16px; transition: background 0.1s; }
        .sidebar-item:hover { background-color: #F2F2F2; }
        .sidebar-icon-container { width: 24px; height: 24px; margin-right: 12px; display: flex; align-items: center; justify-content: center; }
        .sidebar-icon { width: 22px; height: 22px; fill: none; stroke: #232527; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
        .nav-badge { margin-left: auto; background-color: var(--rbx-blue); color: white; font-size: 11px; font-weight: bold; padding: 2px 6px; border-radius: 10px; }
        .btn-upgrade-container { padding: 10px; margin-top: 5px; }
        .btn-upgrade { background-color: var(--rbx-blue); color: white; border: none; padding: 10px; width: 100%; border-radius: 4px; font-weight: bold; font-size: 15px; cursor: pointer; text-align: center; }

        /* Contenedor Principal */
        .main-container { margin-left: 180px; padding-top: 60px; display: flex; justify-content: center; }
        .content { width: 950px; display: flex; gap: 20px; padding: 20px; }
        
        .group-main-content { flex: 1; display: flex; flex-direction: column; gap: 15px; }
        .group-list-sidebar { width: 200px; background: white; border: 1px solid var(--border); align-self: flex-start; }
        .list-item { display: flex; align-items: center; padding: 8px; border-bottom: 1px solid #EEE; text-decoration: none; color: #333; font-size: 13px; }
        .list-item img { width: 30px; height: 30px; margin-right: 10px; object-fit: cover; border-radius: 3px; }
        .list-active { border-left: 4px solid var(--rbx-blue); background: #F8F8F8; font-weight: bold; }
        
        .white-box { background: white; border: 1px solid var(--border); padding: 15px; position: relative; }
        .group-header { display: flex; gap: 20px; position: relative; }
        .group-logo { width: 150px; height: 150px; border: 1px solid #EEE; object-fit: cover; }
        .btn-join { position: absolute; right: 0; top: 0; background: white; border: 1px solid var(--border); padding: 8px 20px; font-weight: bold; cursor: pointer; }
        
        .members-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(80px, 1fr)); gap: 15px; margin-top: 15px; }
        .member-card { text-align: center; text-decoration: none; color: #333; font-size: 11px; }
        .member-img { width: 75px; height: 75px; border-radius: 50%; border: 1px solid #EEE; margin-bottom: 5px; object-fit: cover; }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="sidebar">
    <div class="sidebar-user">
        <div class="sidebar-user-img" id="sidebar-avatar"></div>
        <span class="sidebar-user-name">
            <?php echo htmlspecialchars($username); ?>
            <?php if ($is_verified == 1): ?>
                <img src="verified.png" class="verified-badge" title="Verified">
            <?php endif; ?>
        </span>
    </div>

    <a href="home.php" class="sidebar-item">
        <div class="sidebar-icon-container"><svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div>
        Home
    </a>
    <a href="profile.php" class="sidebar-item">
        <div class="sidebar-icon-container"><svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></div>
        Profile
    </a>
    <a href="messages.php" class="sidebar-item">
        <div class="sidebar-icon-container"><svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></div>
        Messages
    </a>
    <a href="friends.php" class="sidebar-item">
        <div class="sidebar-icon-container"><svg class="sidebar-icon" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg></div>
        Friends <span class="nav-badge">0</span>
    </a>
    <a href="groups.php" class="sidebar-item" style="background: #F2F2F2;">
        <div class="sidebar-icon-container"><svg class="sidebar-icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg></div>
        Groups
    </a>
    <?php if ($user_rank === 'Admin'): ?>
    <a href="admin/index.php" class="sidebar-item" style="color: var(--rbx-admin-red); font-weight: bold;">
        <div class="sidebar-icon-container"><svg class="sidebar-icon" style="stroke: var(--rbx-admin-red);" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg></div>
        Admin
    </a>
    <?php endif; ?>

    <div class="btn-upgrade-container"><button class="btn-upgrade">Upgrade Now</button></div>
</div>

<div class="main-container">
    <div class="content">
        <div class="group-list-sidebar">
            <h3 style="padding: 10px; margin: 0; font-size: 14px; border-bottom: 1px solid #eee;">My Groups</h3>
            <?php foreach ($sidebar_groups_list as $sg): ?>
                <a href="groups.php?id=<?php echo $sg['id']; ?>" class="list-item <?php echo ($sg['id'] == $group_id) ? 'list-active' : ''; ?>">
                    <img src="uploads/groups/<?php echo htmlspecialchars($sg['logo']); ?>" onerror="this.src='default_group.png'">
                    <span><?php echo htmlspecialchars($sg['name']); ?></span>
                </a>
            <?php endforeach; ?>
        </div>

        <div class="group-main-content">
            <div class="white-box">
                <div class="group-header">
                    <img src="uploads/groups/<?php echo htmlspecialchars($group['logo']); ?>" class="group-logo" onerror="this.src='default_group.png'">
                    <div>
                        <h1 style="margin:0; font-size: 24px;"><?php echo htmlspecialchars($group['name']); ?></h1>
                        <div style="font-size: 14px; margin-top: 5px;">
                            By <b style="color:var(--rbx-blue)"><?php echo htmlspecialchars($group['owner_name']); ?></b>
                            <?php if ($group['owner_verified']): ?>
                                <img src="verified.png" class="verified-badge">
                            <?php endif; ?>
                        </div>
                        <div style="display: flex; gap: 20px; margin-top: 20px;">
                            <div><small style="color:#999; display:block; font-size:10px;">MEMBERS</small><b><?php echo number_format($member_count); ?></b></div>
                            <div><small style="color:#999; display:block; font-size:10px;">YOUR RANK</small><b><?php echo $user_membership ? htmlspecialchars($user_membership['rank_name']) : 'Guest'; ?></b></div>
                        </div>
                    </div>
                    <?php if (!$user_membership): ?>
                        <form method="POST"><button type="submit" name="join_group" class="btn-join">Join Group</button></form>
                    <?php endif; ?>
                </div>
            </div>

            <div class="white-box">
                <h4 style="margin:0 0 10px 0; font-size: 14px; color: #666;">Group Shout</h4>
                <div style="display: flex; gap: 15px; align-items: center;">
                    <?php 
                        $owner_render_stmt = $pdo->prepare("SELECT render_url FROM fake_renders WHERE item_id = ? LIMIT 1");
                        $owner_render_stmt->execute([$group['owner_id']]);
                        $o_render = $owner_render_stmt->fetchColumn();
                    ?>
                    <img src="<?php echo $o_render ?: $default_avatar; ?>" style="width: 50px; height: 50px; border-radius: 50%; border: 1px solid #ddd;">
                    <div>
                        <b style="color:var(--rbx-blue); font-size: 13px;"><?php echo htmlspecialchars($group['owner_name']); ?></b>
                        <div style="font-size: 13px; margin-top: 2px;"><?php echo htmlspecialchars($group['shout_text'] ?: 'No news today.'); ?></div>
                    </div>
                </div>
            </div>

            <div class="white-box">
                <h4 style="margin:0 0 10px 0; font-size: 14px; color: #666;">Description</h4>
                <div style="font-size: 13px; line-height: 1.6;"><?php echo nl2br(htmlspecialchars($group['description'])); ?></div>
            </div>

            <div class="white-box">
                <h4 style="margin:0 0 15px 0; font-size: 14px; color: #666;">Members</h4>
                <div class="members-grid">
                    <?php foreach ($members as $m): ?>
                        <a href="profile.php?id=<?php echo $m['id']; ?>" class="member-card">
                            <img src="<?php echo $m['user_render'] ?: $default_avatar; ?>" class="member-img">
                            <div>
                                <?php echo htmlspecialchars($m['username']); ?>
                                <?php if ($m['is_verified']): ?>
                                    <img src="verified.png" class="verified-badge">
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const rendersMap = <?php echo json_encode($renders_map); ?>;
    const defaultImg = '<?php echo $default_avatar; ?>';

    function updateAvatar() {
        const equippedId = localStorage.getItem('equipped_item_id');
        const sidebarAvatar = document.getElementById('sidebar-avatar');
        if (sidebarAvatar) {
            if (equippedId && rendersMap[equippedId]) {
                sidebarAvatar.style.backgroundImage = `url('${rendersMap[equippedId]}')`;
            } else {
                sidebarAvatar.style.backgroundImage = `url('${defaultImg}')`;
            }
        }
    }

    window.onload = updateAvatar;
    // Escuchar si se cambia el avatar en otra pestaña del editor
    window.addEventListener('storage', updateAvatar);
</script>

</body>
</html>